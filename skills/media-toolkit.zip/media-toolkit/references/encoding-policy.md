# Encoding policy

## Stream copy

FFmpeg `-c copy` copies encoded packets into a new container without decoding
and encoding the media. It is the required path for ordinary trimming,
splitting, concatenation, remuxing, and stream extraction.

## Limitations

- Video cuts are constrained by keyframes and packet boundaries.
- Concatenation requires compatible stream layouts and codec parameters.
- A destination container may not support every source stream.
- Container timestamps, indexes, and metadata blocks can change even when
  encoded audio/video packets do not.

## Re-encoding is unavoidable for

- frame-exact cuts away from keyframes,
- resize, crop, rotation baked into pixels,
- burned-in subtitles or overlays,
- GIF creation and timelapse generation,
- speed changes, fades, crossfades and mixing,
- sample-rate, channel-layout or codec changes,
- loudness normalization that modifies samples.

Never hide these operations behind a “lossless” label.
