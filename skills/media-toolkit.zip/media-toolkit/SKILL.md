---
name: media-toolkit
description: Lossless-first audio and video processing for trimming, splitting, merging, remuxing, stream extraction, inspection, thumbnails, captions, GIFs, normalization, and analysis. Use when the user provides or references media files and asks to cut, join, convert, inspect, caption, extract audio or frames, or otherwise process them. For trim, split, merge, remux, or extraction, always attempt FFmpeg stream copy first and never silently re-encode.
---

# Media Toolkit

Use this for deterministic audio and video file work.

## Non-negotiable default: preserve encoded streams

For these operations, begin with `scripts/lossless_media.py`:

- trim or clip,
- fixed-duration split,
- merge/concatenate,
- container change/remux,
- audio, video, or subtitle stream extraction.

Those commands use FFmpeg `-c copy`. They either complete without changing the encoded streams or fail. **Never add an automatic transcoding fallback.**

A lossless video cut is packet/keyframe accurate. It may begin on the nearest usable keyframe. If the user requires a frame-exact boundary, explain that it requires re-encoding and obtain explicit acceptance before using a transcoding workflow.

## Routing

| Request | Primary tool | Encoding policy |
|---|---|---|
| Trim audio/video | `lossless_media.py trim` | stream copy only |
| Split by duration | `lossless_media.py split` | stream copy only |
| Merge matching files | `lossless_media.py concat` | stream copy only; refuse mismatched streams |
| Change container | `lossless_media.py remux` | stream copy only |
| Extract encoded stream | `lossless_media.py extract` | stream copy only |
| Convert audio | `audio_converter.py` | byte copy/remux first; `--allow-reencode` required |
| Podcast chapters at silence | `podcast_splitter.py` | analysis may decode; exports stream-copy original packets |
| Inspect video/audio | metadata/analyzer scripts | read-only |
| Extract thumbnails | `video_thumbnail_extractor.py` | video unchanged; generated images are new files |
| Burn captions, make GIF/timelapse, normalize, speed, fade, crossfade | focused script | inherently re-encoded; say so before running |

## Workflow

1. Probe the input with FFprobe before choosing a path.
2. Preserve the original file and write to a new output.
3. For trim/merge/remux/extract, use stream copy and verify that output stream codecs and layouts match.
4. Refuse lossless concatenation when codec, profile, dimensions, pixel format, sample rate, channels, or channel layout differ.
5. Use re-encoding only when the requested effect mathematically changes decoded samples or pixels, or when the user explicitly accepts it.
6. Report whether the output was:
   - byte-for-byte copied,
   - remuxed/stream-copied,
   - or re-encoded.

## Examples

```bash
python scripts/lossless_media.py probe input.mkv
python scripts/lossless_media.py trim input.mp4 clip.mp4 --start 00:01:20 --end 00:02:10
python scripts/lossless_media.py concat joined.mp4 part1.mp4 part2.mp4
python scripts/lossless_media.py remux input.mkv output.mp4
python scripts/lossless_media.py extract input.mkv audio.m4a --stream audio
```

## Guardrails

- Never overwrite the source.
- Never call a stream-copy operation “frame exact.”
- Never claim conversion improves an already lossy source.
- Do not normalize, resize, caption, crossfade, change speed, change frame rate, or change sample rate under the label “lossless.”
- Keep metadata and chapters when the destination container supports them.
