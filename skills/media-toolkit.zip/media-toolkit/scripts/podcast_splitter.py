#!/usr/bin/env python3
"""Silence-aware podcast splitting with lossless stream-copy exports.

Silence detection decodes audio for analysis, but exported chapter files copy
the original encoded packets. Removing or shortening silence changes the
timeline and therefore belongs to an explicitly lossy/re-encoded workflow.
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path
from typing import Optional

from lossless_media import MediaError, trim


class PodcastSplitter:
    def __init__(
        self,
        filepath: str,
        silence_thresh: float = -40,
        min_silence_len: int = 1000,
        keep_silence: int = 300,
    ):
        self.filepath = Path(filepath)
        if not self.filepath.is_file():
            raise FileNotFoundError(f"Audio file not found: {filepath}")
        self.silence_thresh = silence_thresh
        self.min_silence_len = min_silence_len
        self.keep_silence = keep_silence
        self._audio = None
        self._silences: list[tuple[int, int]] = []
        self._segments: list[dict] = []

    def _load(self):
        if self._audio is None:
            try:
                from pydub import AudioSegment
            except ImportError as exc:
                raise MediaError("pydub is required for silence detection") from exc
            self._audio = AudioSegment.from_file(self.filepath)

    def detect_silence(self) -> list[tuple[int, int]]:
        self._load()
        from pydub.silence import detect_silence
        self._silences = [
            tuple(region) for region in detect_silence(
                self._audio,
                min_silence_len=self.min_silence_len,
                silence_thresh=self.silence_thresh,
            )
        ]
        return self._silences

    def split_by_silence(
        self,
        min_silence_len: Optional[int] = None,
        max_segments: Optional[int] = None,
    ) -> list[dict]:
        self._load()
        from pydub.silence import detect_nonsilent
        regions = detect_nonsilent(
            self._audio,
            min_silence_len=min_silence_len or self.min_silence_len,
            silence_thresh=self.silence_thresh,
        )
        total = len(self._audio)
        expanded: list[list[int]] = []
        for start, end in regions:
            start = max(0, start - self.keep_silence)
            end = min(total, end + self.keep_silence)
            if expanded and start <= expanded[-1][1]:
                expanded[-1][1] = max(expanded[-1][1], end)
            else:
                expanded.append([start, end])

        if max_segments and len(expanded) > max_segments:
            expanded = expanded[:max_segments]
            expanded[-1][1] = regions[-1][1]

        self._segments = [
            {
                "index": index,
                "start": start,
                "end": end,
                "duration": end - start,
            }
            for index, (start, end) in enumerate(expanded)
        ]
        return list(self._segments)

    def print_silence_report(self) -> None:
        silences = self.detect_silence()
        print(f"{self.filepath.name}: {len(silences)} silence regions")
        for index, (start, end) in enumerate(silences, 1):
            print(f"{index:03d}: {start / 1000:.3f}s - {end / 1000:.3f}s")

    def export_segments(
        self,
        output_dir: str,
        prefix: str = "segment",
        format: Optional[str] = None,
        bitrate: int = 192,  # retained for API compatibility; intentionally unused
    ) -> list[str]:
        if not self._segments:
            self.split_by_silence()
        output_root = Path(output_dir)
        output_root.mkdir(parents=True, exist_ok=True)
        suffix = f".{format.lstrip('.')}" if format else self.filepath.suffix

        outputs: list[str] = []
        for segment in self._segments:
            output = output_root / f"{prefix}_{segment['index'] + 1:02d}{suffix}"
            trim(
                self.filepath,
                output,
                start=segment["start"] / 1000,
                end=segment["end"] / 1000,
                overwrite=True,
            )
            outputs.append(str(output))
        return outputs

    def remove_silence(self, *args, **kwargs):
        raise MediaError(
            "Removing silence changes the timeline and requires re-encoding. "
            "This lossless splitter intentionally refuses it."
        )

    shorten_silence = remove_silence
    strip_silence = remove_silence


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Detect silence and export lossless stream-copy podcast chapters"
    )
    parser.add_argument("--input", "-i", required=True)
    parser.add_argument("--output-dir", "-d")
    parser.add_argument("--detect-only", action="store_true")
    parser.add_argument("--threshold", "-t", type=float, default=-40)
    parser.add_argument("--min-silence", "-m", type=int, default=1000)
    parser.add_argument("--keep-silence", "-k", type=int, default=300)
    parser.add_argument("--max-segments", type=int)
    parser.add_argument("--prefix", default="segment")
    parser.add_argument("--format", "-f")
    args = parser.parse_args()

    try:
        splitter = PodcastSplitter(
            args.input,
            silence_thresh=args.threshold,
            min_silence_len=args.min_silence,
            keep_silence=args.keep_silence,
        )
        if args.detect_only:
            splitter.print_silence_report()
            return 0
        if not args.output_dir:
            parser.error("--output-dir is required unless --detect-only is used")
        splitter.split_by_silence(max_segments=args.max_segments)
        print("\n".join(splitter.export_segments(
            args.output_dir, prefix=args.prefix, format=args.format
        )))
        return 0
    except MediaError as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
