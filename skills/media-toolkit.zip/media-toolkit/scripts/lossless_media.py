#!/usr/bin/env python3
"""
Lossless-first audio/video operations powered by FFmpeg stream copy.

The tool NEVER falls back to transcoding. If the requested container cannot
hold the existing streams, or inputs cannot be concatenated safely, it fails
with an actionable error.

Stream-copy trimming is packet/keyframe accurate, not necessarily frame exact.
That is the unavoidable price of keeping the encoded media untouched.
"""

from __future__ import annotations

import argparse
import json
import os
import shlex
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path
from typing import Any, Iterable, Optional


class MediaError(RuntimeError):
    pass


def require_binary(name: str) -> str:
    path = shutil.which(name)
    if not path:
        raise MediaError(f"{name} is required but was not found on PATH")
    return path


def run(command: list[str], *, capture: bool = False) -> subprocess.CompletedProcess[str]:
    try:
        return subprocess.run(
            command,
            check=True,
            text=True,
            stdout=subprocess.PIPE if capture else None,
            stderr=subprocess.PIPE if capture else None,
        )
    except subprocess.CalledProcessError as exc:
        detail = (exc.stderr or exc.stdout or "").strip()
        raise MediaError(detail or f"Command failed: {shlex.join(command)}") from exc


def parse_time(value: Optional[str | float | int]) -> Optional[float]:
    if value is None:
        return None
    if isinstance(value, (int, float)):
        seconds = float(value)
    else:
        text = str(value).strip()
        if ":" not in text:
            seconds = float(text)
        else:
            parts = [float(part) for part in text.split(":")]
            if len(parts) == 2:
                seconds = parts[0] * 60 + parts[1]
            elif len(parts) == 3:
                seconds = parts[0] * 3600 + parts[1] * 60 + parts[2]
            else:
                raise MediaError(f"Invalid time value: {value}")
    if seconds < 0:
        raise MediaError("Time values cannot be negative")
    return seconds


def probe(path: str | Path) -> dict[str, Any]:
    require_binary("ffprobe")
    target = Path(path)
    if not target.is_file():
        raise MediaError(f"Input file does not exist: {target}")
    result = run(
        [
            "ffprobe", "-v", "error",
            "-show_entries",
            "format=filename,format_name,duration,size,bit_rate:stream=index,codec_type,codec_name,profile,width,height,pix_fmt,sample_rate,channels,channel_layout",
            "-of", "json",
            str(target),
        ],
        capture=True,
    )
    return json.loads(result.stdout)


def duration(path: str | Path) -> float:
    data = probe(path)
    try:
        return float(data["format"]["duration"])
    except (KeyError, TypeError, ValueError) as exc:
        raise MediaError(f"Could not determine duration: {path}") from exc


def stream_signature(path: str | Path) -> list[tuple[Any, ...]]:
    data = probe(path)
    signature: list[tuple[Any, ...]] = []
    for stream in data.get("streams", []):
        signature.append(
            (
                stream.get("codec_type"),
                stream.get("codec_name"),
                stream.get("profile"),
                stream.get("width"),
                stream.get("height"),
                stream.get("pix_fmt"),
                stream.get("sample_rate"),
                stream.get("channels"),
                stream.get("channel_layout"),
            )
        )
    return signature


def verify_stream_copy(source: str | Path, output: str | Path) -> None:
    before = stream_signature(source)
    after = stream_signature(output)
    if before != after:
        raise MediaError(
            "Output stream layout/codecs differ from the source. "
            "The operation was not a clean stream copy."
        )


def _base_copy_command(overwrite: bool) -> list[str]:
    require_binary("ffmpeg")
    return ["ffmpeg", "-hide_banner", "-nostdin", "-y" if overwrite else "-n"]


def trim(
    source: str | Path,
    output: str | Path,
    *,
    start: Optional[str | float] = None,
    end: Optional[str | float] = None,
    overwrite: bool = False,
    verify: bool = True,
) -> Path:
    source = Path(source)
    output = Path(output)
    if source.resolve() == output.resolve():
        raise MediaError("Input and output must be different files")

    start_s = parse_time(start) or 0.0
    end_s = parse_time(end)
    total = duration(source)
    if end_s is None:
        end_s = total
    if start_s >= end_s:
        raise MediaError("Start must be before end")
    if start_s >= total:
        raise MediaError(f"Start is outside the file duration ({total:.3f}s)")
    end_s = min(end_s, total)

    output.parent.mkdir(parents=True, exist_ok=True)
    command = _base_copy_command(overwrite)
    if start_s:
        command += ["-ss", f"{start_s:.6f}"]
    command += ["-i", str(source)]
    command += ["-t", f"{end_s - start_s:.6f}"]
    command += [
        "-map", "0",
        "-map_metadata", "0",
        "-map_chapters", "0",
        "-c", "copy",
        "-avoid_negative_ts", "make_zero",
        str(output),
    ]
    run(command)
    if verify:
        verify_stream_copy(source, output)
    return output


def remux(
    source: str | Path,
    output: str | Path,
    *,
    overwrite: bool = False,
    verify: bool = True,
) -> Path:
    source = Path(source)
    output = Path(output)
    if source.resolve() == output.resolve():
        raise MediaError("Input and output must be different files")
    output.parent.mkdir(parents=True, exist_ok=True)

    command = _base_copy_command(overwrite) + [
        "-i", str(source),
        "-map", "0",
        "-map_metadata", "0",
        "-map_chapters", "0",
        "-c", "copy",
        str(output),
    ]
    run(command)
    if verify:
        verify_stream_copy(source, output)
    return output


def _escape_concat_path(path: Path) -> str:
    # FFmpeg concat demuxer uses single-quoted paths; escape an embedded quote.
    return str(path.resolve()).replace("'", r"'\''")


def concat(
    sources: Iterable[str | Path],
    output: str | Path,
    *,
    overwrite: bool = False,
    verify: bool = True,
) -> Path:
    files = [Path(item) for item in sources]
    if len(files) < 2:
        raise MediaError("Concatenation needs at least two input files")
    for item in files:
        if not item.is_file():
            raise MediaError(f"Input file does not exist: {item}")

    expected = stream_signature(files[0])
    for item in files[1:]:
        if stream_signature(item) != expected:
            raise MediaError(
                f"Cannot concatenate losslessly because stream parameters differ: {item.name}. "
                "Inputs must have matching codec, profile, dimensions/pixel format, "
                "sample rate and channel layout."
            )

    output = Path(output)
    output.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile("w", suffix=".ffconcat", encoding="utf-8", delete=False) as handle:
        list_path = Path(handle.name)
        handle.write("ffconcat version 1.0\n")
        for item in files:
            handle.write(f"file '{_escape_concat_path(item)}'\n")

    try:
        command = _base_copy_command(overwrite) + [
            "-f", "concat",
            "-safe", "0",
            "-i", str(list_path),
            "-map", "0",
            "-map_metadata", "0",
            "-c", "copy",
            "-avoid_negative_ts", "make_zero",
            str(output),
        ]
        run(command)
    finally:
        list_path.unlink(missing_ok=True)

    if verify and stream_signature(output) != expected:
        raise MediaError("Concatenated output does not preserve the input stream layout/codecs")
    return output


def split_fixed(
    source: str | Path,
    output_dir: str | Path,
    chunk_duration: float,
    *,
    prefix: str = "part",
    overwrite: bool = False,
    verify: bool = True,
) -> list[Path]:
    if chunk_duration <= 0:
        raise MediaError("Chunk duration must be positive")

    source = Path(source)
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    total = duration(source)
    suffix = source.suffix
    outputs: list[Path] = []

    cursor = 0.0
    index = 1
    while cursor < total - 0.001:
        end = min(cursor + chunk_duration, total)
        out = output_dir / f"{prefix}_{index:03d}{suffix}"
        trim(
            source,
            out,
            start=cursor,
            end=end,
            overwrite=overwrite,
            verify=verify,
        )
        outputs.append(out)
        cursor = end
        index += 1
    return outputs


def extract_stream(
    source: str | Path,
    output: str | Path,
    *,
    stream: str = "audio",
    index: int = 0,
    overwrite: bool = False,
) -> Path:
    mapping = {"audio": "a", "video": "v", "subtitle": "s"}
    if stream not in mapping:
        raise MediaError("stream must be audio, video, or subtitle")
    source = Path(source)
    output = Path(output)
    output.parent.mkdir(parents=True, exist_ok=True)
    command = _base_copy_command(overwrite) + [
        "-i", str(source),
        "-map", f"0:{mapping[stream]}:{index}",
        "-map_metadata", "0",
        "-c", "copy",
        str(output),
    ]
    run(command)
    return output


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Lossless-first audio/video trim, split, concat, remux and stream extraction",
        epilog=(
            "No command silently transcodes. Video trims start on an available keyframe, "
            "so frame-exact cuts require re-encoding and are intentionally outside this tool."
        ),
    )
    sub = parser.add_subparsers(dest="command", required=True)

    p_probe = sub.add_parser("probe", help="Inspect streams and container")
    p_probe.add_argument("input")

    p_trim = sub.add_parser("trim", help="Trim with FFmpeg stream copy")
    p_trim.add_argument("input")
    p_trim.add_argument("output")
    p_trim.add_argument("--start")
    p_trim.add_argument("--end")
    p_trim.add_argument("--overwrite", action="store_true")
    p_trim.add_argument("--no-verify", action="store_true")

    p_split = sub.add_parser("split", help="Split into fixed-duration stream-copy chunks")
    p_split.add_argument("input")
    p_split.add_argument("output_dir")
    p_split.add_argument("--duration", type=float, required=True)
    p_split.add_argument("--prefix", default="part")
    p_split.add_argument("--overwrite", action="store_true")
    p_split.add_argument("--no-verify", action="store_true")

    p_concat = sub.add_parser("concat", help="Join compatible files without re-encoding")
    p_concat.add_argument("output")
    p_concat.add_argument("inputs", nargs="+")
    p_concat.add_argument("--overwrite", action="store_true")
    p_concat.add_argument("--no-verify", action="store_true")

    p_remux = sub.add_parser("remux", help="Change container without changing streams")
    p_remux.add_argument("input")
    p_remux.add_argument("output")
    p_remux.add_argument("--overwrite", action="store_true")
    p_remux.add_argument("--no-verify", action="store_true")

    p_extract = sub.add_parser("extract", help="Extract one encoded stream unchanged")
    p_extract.add_argument("input")
    p_extract.add_argument("output")
    p_extract.add_argument("--stream", choices=["audio", "video", "subtitle"], default="audio")
    p_extract.add_argument("--index", type=int, default=0)
    p_extract.add_argument("--overwrite", action="store_true")

    return parser


def main() -> int:
    args = build_parser().parse_args()
    try:
        if args.command == "probe":
            print(json.dumps(probe(args.input), indent=2))
        elif args.command == "trim":
            out = trim(
                args.input, args.output, start=args.start, end=args.end,
                overwrite=args.overwrite, verify=not args.no_verify,
            )
            print(f"Lossless stream-copy trim: {out}")
        elif args.command == "split":
            outputs = split_fixed(
                args.input, args.output_dir, args.duration,
                prefix=args.prefix, overwrite=args.overwrite, verify=not args.no_verify,
            )
            print("\n".join(str(item) for item in outputs))
        elif args.command == "concat":
            out = concat(
                args.inputs, args.output,
                overwrite=args.overwrite, verify=not args.no_verify,
            )
            print(f"Lossless stream-copy concat: {out}")
        elif args.command == "remux":
            out = remux(
                args.input, args.output,
                overwrite=args.overwrite, verify=not args.no_verify,
            )
            print(f"Lossless remux: {out}")
        elif args.command == "extract":
            out = extract_stream(
                args.input, args.output, stream=args.stream,
                index=args.index, overwrite=args.overwrite,
            )
            print(f"Lossless stream extraction: {out}")
        return 0
    except MediaError as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
