# Scripts

Use `lossless_media.py` first for trim, split, concat, remux and extraction.
It never transcodes.

Scripts such as `video_captioner.py`, `gif_workshop.py`,
`timelapse_creator.py`, `audio_normalizer.py`, and effects tools necessarily
create newly encoded media. Run those only for an explicitly requested
transform and report the re-encoding.
