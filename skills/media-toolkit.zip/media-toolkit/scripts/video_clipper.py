#!/usr/bin/env python3
"""Lossless-only video clipping and fixed-duration splitting."""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

from lossless_media import MediaError, split_fixed, trim


class VideoClipper:
    def __init__(self):
        self.filepath: Path | None = None

    def load(self, filepath: str) -> "VideoClipper":
        self.filepath = Path(filepath)
        if not self.filepath.is_file():
            raise FileNotFoundError(f"Video file not found: {filepath}")
        return self

    def extract_segment(self, start: float, end: float, output: str) -> str:
        if self.filepath is None:
            raise MediaError("No video loaded")
        return str(trim(self.filepath, output, start=start, end=end, overwrite=True))

    def trim(self, start=None, end=None, output=None) -> str:
        if self.filepath is None or output is None:
            raise MediaError("Input and output are required")
        return str(trim(self.filepath, output, start=start, end=end, overwrite=True))

    def split_by_duration(self, chunk_duration: float, output_dir: str) -> list[str]:
        if self.filepath is None:
            raise MediaError("No video loaded")
        return [str(path) for path in split_fixed(
            self.filepath, output_dir, chunk_duration, overwrite=True
        )]

    def close(self) -> None:
        return None


def main() -> int:
    parser = argparse.ArgumentParser(
        description=(
            "Lossless-only video clipping. Cuts are keyframe/packet accurate; "
            "frame-exact cuts would require re-encoding and are not attempted."
        )
    )
    parser.add_argument("--input", "-i", required=True)
    parser.add_argument("--output", "-o", required=True)
    parser.add_argument("--start")
    parser.add_argument("--end")
    parser.add_argument("--split", type=float)
    parser.add_argument("--overwrite", action="store_true")
    args = parser.parse_args()

    try:
        if args.split:
            outputs = split_fixed(
                args.input, args.output, args.split, overwrite=args.overwrite
            )
            print("\n".join(str(path) for path in outputs))
        else:
            print(trim(
                args.input, args.output, start=args.start, end=args.end,
                overwrite=args.overwrite,
            ))
        return 0
    except MediaError as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
