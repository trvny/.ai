#!/usr/bin/env python3
"""Lossless-first audio conversion.

Default behavior is byte copy (same extension) or FFmpeg remux (different
container) with ``-c copy``. The program never silently transcodes. Operations
that change samples or codec require ``--allow-reencode``.
"""

from __future__ import annotations

import argparse
import shutil
import subprocess
import sys
from pathlib import Path

from lossless_media import MediaError, probe, remux


CODECS = {
    "mp3": "libmp3lame",
    "wav": "pcm_s24le",
    "flac": "flac",
    "ogg": "libopus",
    "opus": "libopus",
    "m4a": "aac",
    "aac": "aac",
    "aiff": "pcm_s24be",
}


def reencode(
    source: Path,
    output: Path,
    *,
    bitrate: int | None,
    sample_rate: int | None,
    channels: int | None,
    normalize: bool,
    overwrite: bool,
) -> Path:
    suffix = output.suffix.lower().lstrip(".")
    codec = CODECS.get(suffix)
    if not codec:
        raise MediaError(f"No explicit re-encode profile for .{suffix}")
    command = ["ffmpeg", "-hide_banner", "-nostdin", "-y" if overwrite else "-n", "-i", str(source)]
    command += ["-map", "0:a:0", "-map_metadata", "0", "-vn", "-c:a", codec]
    if bitrate and codec in {"libmp3lame", "libopus", "aac"}:
        command += ["-b:a", f"{bitrate}k"]
    if sample_rate:
        command += ["-ar", str(sample_rate)]
    if channels:
        command += ["-ac", str(channels)]
    if normalize:
        command += ["-af", "loudnorm"]
    command.append(str(output))
    output.parent.mkdir(parents=True, exist_ok=True)
    try:
        subprocess.run(command, check=True)
    except subprocess.CalledProcessError as exc:
        raise MediaError("Explicit audio re-encoding failed") from exc
    return output


def convert(
    source: str,
    output: str,
    *,
    allow_reencode: bool = False,
    bitrate: int | None = None,
    sample_rate: int | None = None,
    channels: int | None = None,
    normalize: bool = False,
    overwrite: bool = False,
) -> Path:
    src = Path(source)
    dst = Path(output)
    if not src.is_file():
        raise MediaError(f"Input file does not exist: {src}")
    if src.resolve() == dst.resolve():
        raise MediaError("Input and output must be different files")

    sample_change = any((bitrate, sample_rate, channels, normalize))
    if sample_change and not allow_reencode:
        raise MediaError(
            "The requested bitrate/sample-rate/channel/normalization change requires "
            "re-encoding. Re-run with --allow-reencode only if that quality tradeoff is intended."
        )

    if allow_reencode and sample_change:
        return reencode(
            src, dst, bitrate=bitrate, sample_rate=sample_rate,
            channels=channels, normalize=normalize, overwrite=overwrite,
        )

    dst.parent.mkdir(parents=True, exist_ok=True)
    if src.suffix.lower() == dst.suffix.lower():
        if dst.exists() and not overwrite:
            raise MediaError(f"Output exists: {dst}")
        shutil.copy2(src, dst)
        return dst

    # Different extension: try a true remux. It fails instead of transcoding.
    return remux(src, dst, overwrite=overwrite)


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Lossless-first audio copy/remux; explicit opt-in for transcoding"
    )
    parser.add_argument("--input", "-i", required=True)
    parser.add_argument("--output", "-o")
    parser.add_argument("--info", action="store_true")
    parser.add_argument("--bitrate", "-b", type=int)
    parser.add_argument("--sample-rate", "-s", type=int)
    parser.add_argument("--channels", "-c", type=int, choices=[1, 2])
    parser.add_argument("--normalize", action="store_true")
    parser.add_argument("--allow-reencode", action="store_true")
    parser.add_argument("--overwrite", action="store_true")
    args = parser.parse_args()

    try:
        if args.info:
            import json
            print(json.dumps(probe(args.input), indent=2))
            return 0
        if not args.output:
            parser.error("--output is required unless --info is used")
        out = convert(
            args.input, args.output,
            allow_reencode=args.allow_reencode,
            bitrate=args.bitrate, sample_rate=args.sample_rate,
            channels=args.channels, normalize=args.normalize,
            overwrite=args.overwrite,
        )
        print(out)
        return 0
    except MediaError as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
