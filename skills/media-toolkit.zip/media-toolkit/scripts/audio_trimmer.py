#!/usr/bin/env python3
"""Lossless-only audio trimming and concatenation.

This compatibility wrapper intentionally exposes only operations that can use
FFmpeg stream copy. Fades, normalization, speed changes, overlays and
crossfades are not silently re-encoded here.
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path
from typing import Optional

from lossless_media import MediaError, concat, parse_time, trim


class AudioTrimmer:
    def __init__(self, filepath: str):
        self.filepath = Path(filepath)
        if not self.filepath.is_file():
            raise FileNotFoundError(f"Audio file not found: {filepath}")
        self._start: Optional[float] = None
        self._end: Optional[float] = None

    def trim(self, start=None, end=None, start_ms=None, end_ms=None) -> "AudioTrimmer":
        self._start = parse_time(start) if start is not None else (
            start_ms / 1000 if start_ms is not None else None
        )
        self._end = parse_time(end) if end is not None else (
            end_ms / 1000 if end_ms is not None else None
        )
        return self

    def save(self, output: str, **_: object) -> str:
        return str(trim(self.filepath, output, start=self._start, end=self._end, overwrite=True))

    @classmethod
    def concatenate(cls, files: list[str], output: str, **_: object) -> str:
        return str(concat(files, output, overwrite=True))

    @staticmethod
    def _requires_reencode(operation: str):
        raise MediaError(
            f"{operation} changes decoded samples and cannot be lossless. "
            "Use the dedicated effect/normalization tool only after explicitly accepting re-encoding."
        )

    fade_in = lambda self, *a, **k: self._requires_reencode("fade-in")
    fade_out = lambda self, *a, **k: self._requires_reencode("fade-out")
    speed = lambda self, *a, **k: self._requires_reencode("speed change")
    reverse = lambda self, *a, **k: self._requires_reencode("reverse")
    gain = lambda self, *a, **k: self._requires_reencode("gain adjustment")
    normalize = lambda self, *a, **k: self._requires_reencode("normalization")
    overlay = lambda self, *a, **k: self._requires_reencode("overlay")
    concatenate_with_crossfade = lambda *a, **k: AudioTrimmer._requires_reencode("crossfade")


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Lossless-only audio trim or concat using FFmpeg stream copy"
    )
    parser.add_argument("--input", "-i")
    parser.add_argument("--output", "-o", required=True)
    parser.add_argument("--start")
    parser.add_argument("--end")
    parser.add_argument("--concat", nargs="+")
    parser.add_argument("--overwrite", action="store_true")
    args = parser.parse_args()

    try:
        if args.concat:
            print(concat(args.concat, args.output, overwrite=args.overwrite))
        else:
            if not args.input:
                parser.error("--input is required unless --concat is used")
            print(
                trim(
                    args.input, args.output, start=args.start, end=args.end,
                    overwrite=args.overwrite,
                )
            )
        return 0
    except MediaError as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
