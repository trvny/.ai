# Collision Engine — getting past the first joke

Adapted for this skill from the MIT-licensed `meme-marketing` skill (github.com/imMamdouhaboammar/meme-marketing, v3.2.1). Its Arabic/marketing specifics are dropped; the idea engine, gates and relatable-post formulas carry over to Polish dark humor almost unchanged.

**Why this exists:** models write the most probable joke first, and the most probable joke is the one the audience has already scrolled past (one study: >90% of 1,008 ChatGPT jokes were the same 25). Run the five stages *privately* before writing any variant. Do not show the stages in the output.

```
insight dig -> far-domain collision -> mechanism + register -> sharpen -> kill the obvious
  (truth)          (surprise)              (shape)            (receipts)   (originality)
```

Theory in one line each: incongruity-resolution (mismatch + one-step resolution), bisociation (two frames that never touch), benign violation (feels wrong *and* okay — dark humor lives exactly on that line), debugging theory (we laugh when we catch our own false assumption).

## 1. Insight dig — the private truth

Write the insight as one plain sentence in the audience's words before any joke. Pick 2–3 lenses:

| Lens | Question | PL seed |
|---|---|---|
| Hidden habit | What do they do that never goes in a CV? | odświeżanie śledzenia paczki co 4 minuty |
| Self-lie | What does the calendar disprove? | „od poniedziałku” — 47. poniedziałek |
| Brain-math glitch | Where does intuition fail funnily? | 9,99 zł to w zasadzie 9 zł |
| Unwritten rule | What does everyone obey that nobody wrote down? | nie siada się na miejscu taty przy stole |
| Betrayal | When does a tool/boss/institution flip? | „po okresie próbnym pogadamy o podwyżce” |
| Predictable relative | Which family member always does the same move? | ciocia na komunii: „a dzieci kiedy?” |
| Time freeze | Who still treats them as their younger self? | mama pakuje słoiki 34-latkowi |
| Tiny miracle | What normal event feels like a miracle? | lekarz na NFZ w tym kwartale |
| Energy budget | Where is social energy rationed? | „rozmawialiśmy w marcu, o co ci chodzi” |
| Status gap | Where does effort vs reward show? | 3 lata doświadczenia, oferta 4300 brutto |

Quality check: **recognition** (6/10 of the audience says „to ja”), **privacy** (slightly embarrassing or unspoken — „korki są złe” gives no relief), **specificity** (one object, number, tool, time or person).

## 2. Far-domain collision — where the surprise comes from

1. Write the first three frames that come to mind. **Discard all three.**
2. Pick two distant frames from the bank. LLMs are bad at random choice — rotate deliberately across groups.
3. For each, name the **bridge**: the one shared property that lets the insight live in that frame.
4. Keep the collision whose bridge is obvious *after* you see it and invisible *before*.

**Group A, official voices:** komunikat PKP o opóźnieniu, ostrzeżenie IMGW, pismo z ZUS/US, mObywatel push, ogłoszenia parafialne, apel szkolny, Teleexpress/Wiadomości pasek, regulamin promocji, SMS z banku, IVR infolinii, wyrok sądu, protokół zebrania wspólnoty, wynik wyborów, ulotka leku („przed użyciem…").
**Group B, cultural scripts:** komentarz sportowy (Szpakowski-style tempo, not his quotes), przepis z Kwestii Smaku, zaproszenie na wesele, przysłowie, horoskop, zadanie maturalne, teksty mamy, teksty taty, plotka sąsiedzka, ogłoszenie OLX, opinia na Google Maps, gazetka Lidla, nekrolog, kazanie.
**Group C, tech/platform:** changelog, komunikat błędu, okno uprawnień aplikacji, „wyloguj”, pasek ładowania, „brak miejsca na dysku”, 1% baterii, CAPTCHA, post na LinkedIn, algorytm „polecane”, „wyświetlono”, status paczkomatu, Librus.
**Group D, nature/body:** narracja przyrodnicza, wynik badań, niedobór witamin, opaska fitness, tabliczka w zoo, zachowanie zwierząt.

Worked bridges: *too many responsibilities* × „wyloguj” (both are sessions you can't leave) → „jak się wylogować z dorosłości, bo przycisk jest wyszarzony”. *Fresh start while in debt* × umowa ratalna → „chciałbym zacząć nowe życie, ale stare jeszcze ma raty”. *Relatives who arrive unannounced* × rule of three → „trzy rzeczy przychodzą bez zapowiedzi: śmierć, faktura i ciocia z Radomia”.

## 3. Mechanism + register — the shape

Mechanisms that work in PL dark/shitpost (pick one per variant):

| id | Mechanism | Trap |
|---|---|---|
| `register_hijack` | Official/ceremonial voice on a trivial pain | Religious texts quoted for the gag — keep to everyday formulas |
| `rule_of_three_break` | Two serious items, third derails | Third item too random to resolve |
| `tech_vocab_life` | Software verb for a human state (restart, aktualizacja, wyloguj) | Jargon the audience doesn't use |
| `brain_glitch_confession` | Admitting a faulty belief the reader shares | Real ignorance on a sensitive topic |
| `absurd_precision` | Emotional truth measured with fake exact number (02:13, 97%, 14 słoików) | Number read as a real statistic |
| `cliche_literalized` | Self-help cliché meets a real constraint | Cliché too rare to recognize |
| `mock_authority` | Tiny behaviour judged by principal/judge/kierownik | Reads as genuinely aggressive |
| `time_freeze` | Someone stuck in your past | Mocking the elder instead of the situation |
| `proverb_vs_visual` | Saying illustrated literally by the image | Explaining the link in text |
| `inner_monologue_reveal` | Polite outside caption, honest inner line | Inner line repeats the caption |
| `cross_register_card` | Same concept in three voices, most honest last (EN / urzędowy / blokowy) | Punching at a nationality or region |

**Register** = the voice the line is written in, deliberately borrowed from elsewhere: urzędowy, prezenter, coach rozwoju, konsultant infolinii, mama, tata, HR/LinkedIn, komentator, ksiądz na ogłoszeniach, blokowy szczery.

**Batch variety (GTVH knobs).** For three variants, change **at least two** knobs per variant: script opposition, mechanism, situation, target, narrative form (one-liner / lista / dialog / etykieta / komunikat), register. Changing only words = the same joke three times.

## 4. Sharpen — feed speed

1. **Receipt:** one lived-in detail (paczkomat 02:13, „final_v3_POPRAWIONE.docx”, 4300 brutto, trzecia reorganizacja w roku). A precise absurd number signals exaggeration faster than any adjective.
2. **Turn at the end:** last 2–4 words carry the surprise.
3. **Cut:** most strong captions are under 20 words.
4. **Line break = the comedian's pause** before the turn in text cards.
5. **Texture stays native:** blokowy spelling/cadence when the dialect calls for it; never mix dialect registers in one line.

## 5. Kill the obvious — gates

Run on every variant before output. Fail → repair the smallest failing part; after two failed repairs, switch to a simpler original format.

| Gate | Pass | Repair |
|---|---|---|
| **Predictability** | Cover the last line — a typical reader would guess something else | New far domain from a *different* group |
| **Insight** | Reduces to one plain sentence the audience recognizes and rarely says | Two new lenses; keep the format only if the new insight fits |
| **First-idea graveyard** | Doesn't overlap the three discarded frames | Discard |
| **Template echo** | Works without the famous format; the format carries an insight, never replaces one | Rebuild around an insight |
| **Send test / share mode** | You can name it: *mirror* („to ja”, repost about self) or *arrow* („to ty”, sent to one person — „wysyłam to Krzyśkowi z IT”) | Sharpen the "who" |
| **Receipt** | At least one tactile, scene-specific detail | Add one |
| **Image–text contract** | Caption and image carry different information (tension, counterpoint, dialogue) | Cut the caption that just describes the picture |
| **Feed glance** | Premise lands in ~1.5 s | Fewer words, one idea |
| **Benign violation** | Feels wrong *and* okay; the target is a situation/institution, not a vulnerable person | Re-aim at the situation |

Also reject AI rhetoric: denial-then-reveal („to nie X, to Y”), „kiedy X spotyka Y” slogans, rhetorical questions that answer themselves, puns that need a footnote.

## Relatable posts („to ja” / „oznacz kumpla”)

Text-only posts that get reposted about oneself or tagged at a friend. Drivers: self-recognition, „myślałem, że tylko ja”, identity signalling (the line forgives the sharer a little), proxy speech (can't say it to them, so share it), tagging a recognizable *type*.

**Barnum sweet spot:** not „lubię spać” (too vague), not a full anecdote about one aunt (too niche) — „trzy rzeczy przychodzą bez zapowiedzi…" sits in the middle.

Formulas: private-habit confession · brain-math glitch · tech vocab for life · register hijack · rule-of-three break · family field report (one relative's predictable move reported like a discovery) · energy budget (effort in absurd units) · life-stage fatigue („w wieku 19 lat: …, w wieku 31 lat: …") · cliché made literal · mock authority · cross-register card · mood card (one phrase per line, slow reveal).

Visual shells: dark tweet-card (avatar, handle, white text), black card with centered yellow text, Facebook colored-background text post. Invent the name/handle; never fake a real account.

## If a brand is involved

Usually not this skill's job — but if the user wants a dark meme for their own project/product: the brand is **none**, a **prop** (open tab, mug in the background) or a **character with flaws**, never the superhero that saves the day. Joke must survive covering the logo. No URL, hashtag, promo code or CTA on the canvas. Logo, if any: small badge ~8–10% width, same corner every time, never over a face, never in the text zone.
