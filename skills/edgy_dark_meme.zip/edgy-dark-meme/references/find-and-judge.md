# Find & judge — existing memes and posts, with credits

Not every request needs a new joke. Sometimes the classic already nails it, and the most useful answer is "here's the gold, here's who made it, here's the link". This file covers **finding**, **crediting** and **judging** existing memes, text posts and copypasta. Source reachability below was checked 2026-10-03 — re-check when a source misbehaves.

## 1. When to find instead of (or besides) create

- The user asks: „znajdź”, „jest jakiś mem o…”, „daj gotowca”, „co jest złotem”, „najlepsze memy o…”, „oceń tego mema”, „skąd to jest”.
- The topic has a known classic that beats anything freshly written — then say so and link it.
- **Mixed answer** works well: 1–2 found golds + 1 original that does what they don't.
- A request to judge a meme the user pasted → section 5, no search needed unless they ask for its origin.

## 2. Where to look

Use the host's `web_search` (with `site:`), `web_fetch`, and the sandbox `curl` where noted. Prefer permalinks to posts over search-result pages.

| Source | Best for | How | Notes |
|---|---|---|---|
| **Know Your Meme** | Classics, origin, creator, first date, spread, status (confirmed vs submission), copypasta entries | `web_search site:knowyourmeme.com <topic>`, then fetch the entry | Fetchable from sandbox. The **Origin** section is the credit source of record; "Confirmed" status = proven longevity |
| **JBZD** | Polish dzida-core, current and weekly top | `curl -A <browser UA> https://jbzd.com.pl/top/tydzien` (or `/miesiac`); posts are `jbzd.com.pl/obr/<id>/<slug>`, score in `:score="N"` | Fetchable; the post page carries JSON-LD `"author":{"name","url"}` and `"datePublished"` — that's the uploader, often **not** the creator: check the image for a watermark/handle |
| **Kwejk, Demotywatory, Memy.jeja, Wykop (#heheszki, #pasta)** | Polish classics, demoty, pasty | `web_search site:<domain> <fraza>`; fetch the permalink | Kwejk/Wykop fetch; Demotywatory top paths change — go via search |
| **Reddit** (r/2meirl4meirl, r/me_irl, r/ProgrammerHumor, r/okbuddypolishman, r/Polska, r/copypasta, r/BlackPeopleTwitter-style screenshot subs) | Global dark/relatable, text-post screenshots, copypasta | `web_search site:reddit.com/r/<sub> <topic>`; try `web_fetch` on the permalink | Sandbox `curl` gets 403 (datacenter block); search snippets still give title, sub, votes sometimes |
| **Lemmy** (lemmy.world etc.) | Reddit-like, open API | `curl "https://lemmy.world/api/v3/search?q=<q>&type_=Posts&sort=TopAll&limit=10"` | JSON: `posts[].post.name`, `.counts.score`, `.creator.name`, `.post.ap_id` (permalink) |
| **X / Bluesky / Threads / Tumblr** | Original text posts and tweets that became screenshots | `web_search "<distinctive phrase>"` + `site:` | APIs mostly closed (Bluesky public search 403, Tumblr 429) — search engines only |
| **mysaas.lol** | SaaS/founder/dev memes with built-in credit + license data | API in `render-and-sources.md` | Best-credited source available |
| **Imgflip** | Rarely gold | — | Mostly template-autopilot; use only as a "this format is overfarmed" signal |

Search phrasing: the distinctive words of the punchline beat a topic word („podwyżka po okresie próbnym” > „praca mem”). For a pasted image, describe its visible text and setting; for origin hunting, add `"knowyourmeme"` or the earliest year you suspect.

## 3. Credit protocol — so nobody gets robbed

1. **Credit the creator, not the aggregator.** A repost page, meme-farm account, JBZD/Kwejk upload or Pinterest pin is *where you found it*, not who made it.
2. **Trace origin** in this order: KYM Origin → handle/watermark/signature in the image → earliest dated copy you can find (search the exact visible text with quotes) → the original screenshot's visible account name (tweet/Tumblr screenshots carry it).
3. **Fields per item:** what it is (one line), **autor** (nick/handle + platform) or „autor nieznany”, **data** (first known), **link** (permalink to the original; plus „znalezione na: …” if different), and the license/reuse note when the source states one (mysaas.lol does).
4. **Never invent** an author, date, or link. Unknown stays unknown: „autor nieznany, najwcześniejsza znaleziona kopia: <link, data>”.
5. **Open every link before handing it over** (`web_fetch`/`curl`). Dead or login-walled → say so or drop it.
6. Real-person screenshots (tweets, comments) from private individuals: link the public post; don't add commentary that turns them into a target.

## 4. What you may show

Link + one-line description + why it's gold. **Don't paste whole posts, copypastas or long captions**, and don't re-host or embed someone else's image — the link carries the user to it, and the creator gets the view. A short quoted line (well under 15 words) to identify it is fine. If the user wants to repost it themselves, remind them to credit the creator.

## 5. Gold or not — the judging rubric

Score each axis 0 / 1 / 2. Run the joke-quality gates from `collision-engine.md` on axis A.

| Axis | 0 | 1 | 2 |
|---|---|---|---|
| **A. Joke core** | No insight, or the turn is guessable | Solid but familiar turn | Private truth + a turn you didn't see coming |
| **B. Craft** | Wordy, explained, image and text say the same thing | Clean but loose | Every word earns rent; turn sits in the last words; image and text pull against each other |
| **C. Longevity / mutation** | One-week topical dead end | Still circulates or has some variants | Years later still reposted, spawned variants, entered the language, KYM-confirmed |
| **D. Organic traction (relative)** | Bot/farm numbers or nothing | Decent for its venue | Top of its venue for the period; people quote it in the comments |
| **E. Originality** | Repost-farm reupload, aggregator watermark, default-template autopilot, AI slop | Remix with a small real twist | Original, or the recognized origin of the format |
| **F. Fit** | Off-topic for the ask | Adjacent | Exactly the user's situation, register and dialect |

Normalize traction by venue (a 700-point JBZD week-top ≠ 700 upvotes on a 10M sub) and by age (old posts on dead venues score low on D but can max C).

**Verdict:** **złoto** ≥ 9/12 with A ≥ 1 and no red flag · **srebro** 6–8 (usable, name what holds it back) · **makulatura** < 6 or any red flag.

**Red flags = automatic makulatura:**
- punches down at a vulnerable or protected group, slur as the punchline;
- recent real tragedy with identifiable victims;
- invented "screenshot" or fake quote of a real person presented as genuine; misinformation;
- engagement bait with nothing behind it („oznacz kogoś, kto…” + no joke);
- the joke is explained inside the meme;
- AI-slop tells: mushy too-smooth art, garbled text, „kiedy X spotyka Y” slogan, three jokes stacked where one would do;
- topical reference so dated it needs a footnote (unless the user wants nostalgia).

Taste note: gold is often **ugly** — cheap crop, default font, JPEG rot. Production value is not quality; the turn is.

## 6. Output contract (find mode)

3–5 items unless the user asked for one. Per item, one compact block:

```
1. <one-line description of the meme/post> — złoto
   autor: <nick @platforma | autor nieznany> · <data> · <permalink>
   (znalezione na: <aggregator link>, if different)
   dlaczego: <one line — the insight and why the turn works>
```

Rank by verdict, then fit. If nothing reaches gold, say it plainly, show the best srebro, and offer an original instead — the collision engine exists for exactly that.

**Judge mode** (user pasted a meme): verdict + score line (`A2 B1 C0 D? E2 F2`), one line why, and if srebro, the single smallest repair that would make it gold. Mark unknown axes `?` rather than guessing traction you can't see.
