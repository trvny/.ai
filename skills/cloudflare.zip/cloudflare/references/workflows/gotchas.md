# Workflows gotchas

Check current Workflows docs before relying on syntax, retry behavior or limits.

- A step may run again. External side effects need idempotency keys or existence checks.
- Persist only serializable, intentionally small step outputs.
- Do not place mutable credentials or environment-specific resource IDs into persisted workflow state.
- Long waits and retries should be modeled as workflow behavior, not busy loops.
- Version workflow inputs and outputs when deployments can overlap older instances.
- Distinguish a workflow definition update from the state of already-running instances.
- Test failure and resume paths, not only the happy path.
