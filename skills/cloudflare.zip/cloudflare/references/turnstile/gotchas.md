# Turnstile gotchas

Retrieve current Turnstile docs for token lifetime, fields and error codes.

- Client rendering is not validation. Verify every token server-side.
- Secrets belong only on the server and must not be embedded in client code or logs.
- Tokens are short-lived and single-use. Never cache or replay them.
- Bind validation to the intended action and hostname when the integration supports it.
- Treat missing, expired, duplicate and invalid responses as separate operational signals.
- Reset or refresh the widget after a failed/expired submission.
- Content Security Policy and SPA lifecycle cleanup commonly break otherwise-correct integrations.
- Use official test keys in non-production environments.
