# Observability gotchas

Retrieve current Cloudflare observability documentation before writing
configuration. Keep these stable review checks:

- Prefer structured logs with stable field names over prose-only `console.log`.
- Do not log secrets, authorization headers, full request bodies, or personal data.
- Sampling can hide rare failures; document the sampling choice and preserve error visibility.
- A successful deploy does not prove logs, traces, or analytics are wired correctly. Verify an event end to end.
- Tail sessions and dashboards are diagnostic views, not durable storage guarantees.
- Correlation IDs should cross Worker, Queue, Workflow, Durable Object, and origin boundaries when the architecture spans them.
