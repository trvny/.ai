# Queues gotchas

Check current Queues docs for limits and API shapes.

- Consumers are at-least-once. Make handlers idempotent and tolerate duplicates.
- Acknowledging a message before the side effect is durable can lose work.
- Retrying every failure without classification can create poison-message loops.
- Keep batch handling bounded; one slow message should not indefinitely block unrelated work.
- Preserve enough context for dead-letter diagnosis without copying secrets into message bodies.
- Do not assume FIFO ordering unless the selected product/configuration explicitly guarantees it.
- When producers and consumers deploy separately, treat message schemas as versioned contracts.
