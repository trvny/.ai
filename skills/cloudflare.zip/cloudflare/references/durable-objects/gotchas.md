# Durable Objects gotchas

Retrieve current Durable Objects docs for APIs and quotas.

- Route each coordination key deterministically to one object ID.
- Module-level state is not Durable Object state and may be shared or evicted unexpectedly.
- Constructors can run again; reconstruct required state from storage or attachments.
- WebSocket hibernation clears ordinary in-memory variables. Persist the minimal reconnection state explicitly.
- Storage operations and external side effects have different transaction boundaries. Design for retries.
- Avoid turning one object into a global bottleneck merely because strong consistency is convenient.
- Alarms represent scheduled work for an object, not a general multi-event scheduler.
