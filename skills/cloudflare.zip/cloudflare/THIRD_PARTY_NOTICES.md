# Third-party notices

The selected product gotcha checklists for Observability, Queues, Workflows,
Durable Objects, Turnstile, and Browser Rendering were distilled from the
user-supplied `cloudflare-deploy` package under Apache License 2.0.

Volatile quota tables, dated prices, copied API schemas, and fixed CLI
syntax were intentionally omitted. Current Cloudflare documentation remains
the source of truth.

The full Apache 2.0 license is included under
`licenses/cloudflare-deploy-Apache-2.0.txt`.
