---
name: cloudflare
description: Build, review, debug, or operate Cloudflare projects, especially Workers, Pages, Wrangler, KV, D1, R2, Cron Triggers, bindings, and static assets. Use for Cloudflare code, wrangler configuration or commands, platform architecture, account-resource inspection, deployments, and production reviews. Retrieve current Cloudflare documentation before relying on API shapes, limits, pricing, compatibility flags, or CLI syntax.
---

# Cloudflare

Use this skill as a router and operating checklist, not as a frozen copy of the platform documentation.

## Core workflow

1. Identify the product and whether the request is about architecture, code, configuration, debugging, or an account mutation.
2. Inspect the current project files and existing Cloudflare resources before proposing changes.
3. Retrieve current Cloudflare documentation for any API, limit, price, compatibility date, binding shape, or Wrangler command that may have changed.
4. Read only the matching local reference folder. Local references explain patterns and common failure modes; live docs remain the source of truth.
5. Make the smallest coherent change, validate it, and report exactly what was checked.

## Tool routing

Use the best available route in the current environment:

- **Cloudflare documentation search** for product behavior, limits, configuration, and current recommendations.
- **Cloudflare OpenAPI search** before constructing a REST request. Find the exact endpoint and request schema first.
- **Cloudflare account actions** only when the user clearly asks for an account change. Inspect existing resources and preserve current bindings, variables, routes, and deployment settings unless the task requires changing them.
- **GitHub tools** for repository reads, branches, commits, pull requests, and CI status.
- **Local shell and Wrangler** when a checkout is available. Prefer dry runs, type generation, tests, and configuration validation before deployment.

Do not assume that account access is unavailable, and do not assume that it is connected. Check the tools actually present. Never ask the user to paste an API token into chat.

## Product routing

| Need | Read |
|---|---|
| Worker runtime, handlers, bindings, reviews | `references/workers/` |
| Wrangler commands and `wrangler.jsonc` | `references/wrangler/` |
| Pages and Pages Functions | `references/pages/` |
| KV | `references/kv/` |
| D1 | `references/d1/` |
| R2 | `references/r2/` |
| Scheduled Workers | `references/cron-triggers/` |
| Binding design and typing | `references/bindings/` |
| Workers static assets | `references/static-assets/` |
| REST API and SDK use | `references/api/` |

| Logs, traces, sampling and correlation | `references/observability/` |
| Asynchronous delivery with Queues | `references/queues/` |
| Durable multi-step execution | `references/workflows/` |
| Stateful coordination and WebSockets | `references/durable-objects/` |
| Human verification with Turnstile | `references/turnstile/` |
| Headless browser automation | `references/browser-rendering/` |

For Cloudflare products not covered locally, go directly to current Cloudflare documentation rather than stretching an unrelated reference.

## Write and deploy guardrails

- Read the current file or resource before changing it.
- Preserve secrets and existing bindings. Never embed credentials in source, config, logs, or chat output.
- Prefer bindings from Workers over calling the Cloudflare REST API from inside a Worker.
- Generate types after binding changes and run the project's tests and type checks when available.
- Treat deployment, deletion, migration application, DNS changes, and resource creation as explicit write operations. Do not perform them merely because the user asked for an explanation or review.
- After a write, verify the resulting file, resource, deployment, or CI run. Do not claim success from a request payload alone.

## Freshness rule

If a local reference conflicts with current Cloudflare docs, current docs win. This especially applies to pricing, quotas, API schemas, compatibility behavior, product availability, and Wrangler flags.
