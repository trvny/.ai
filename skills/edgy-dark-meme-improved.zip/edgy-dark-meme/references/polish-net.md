# Polish Internet Meme Dialects

This reference captures reusable mechanics, not exact replicas of existing pages or creators.

## JBZD / dzida-core

### What carries the joke

- **Low ceremony.** The title may be two blunt words. The image does not need a polished setup.
- **Comment-as-punchline.** A dry reply, correction or insult to the situation can outperform the post itself.
- **Local nouns.** Polska B, blok, urząd, paczkomat, Żabka, Januszex, działka, Passat, NFZ, ZUS, OLX, osiedlowy monitoring, sebix logistics.
- **Fast topical mutation.** Current news becomes a format immediately, often without waiting for a canonical template.
- **Crude confidence.** The post does not apologize for bad cropping, bad grammar or low resolution when those traits help the bit.

### Strong shapes

- ordinary photo + one-line hostile observation;
- screenshot + highlighted absurdity + caption;
- fake advice/tutorial where the advice is technically possible and spiritually catastrophic;
- title that undersells a ridiculous image;
- image + second-stage comment punchline.

### Avoid

- trying too hard to sound "internet";
- ten layers of slang in one sentence;
- replacing the joke with pure contempt for a demographic;
- polishing away the accidental/cheap texture that makes the format work.

## Cenzo

Cenzo is mutation humor. The visual edit is not illustration for the caption; it is the joke's main verb.

### Mutation engine

1. Identify the subject's most recognizable visual or lexical feature.
2. Replace it with something semantically nearby, phonetically similar or completely inappropriate.
3. Make the visual substitution literal.
4. Rename/re-caption the subject to match the mutation.
5. Leave the edit slightly too crude to look official.

Useful mutation types:

- head/object swap;
- body becomes product/vehicle/food/tool;
- logo/name phonetic mutation;
- historical/religious/state imagery inserted into banal modern context;
- tiny person in huge object or huge face in tiny frame;
- deliberately mismatched perspective and lighting.

### Texture

Hard cutout, wrong white balance, JPEG blocks, cheap glow, visible scaling artifacts, old forum/imageboard energy. Clean professional compositing can actually make cenzo less funny.

### Cenzopapa lineage

Use as a cultural grammar of irreverent mutation, not as a requirement to reproduce old allegations or exact legacy posts. Papal visual callbacks, yellow/amber tint and `21:37` can be optional seasoning when the request points there.

## Cenzopolityk

Generalized from cenzoduda-style political edits.

### Visual grammar

- campaign billboard;
- official presidential portrait;
- ministry/public-service announcement;
- patriotic red-white banner;
- TV news lower-third;
- ballot or referendum graphic;
- municipal poster or state-company ad.

### Joke engine

The format promises dignity and authority. The caption removes both.

Best turns:

- absurdly small promise framed as historic achievement;
- slogan that accidentally admits the real motive;
- bureaucratic wording describing something embarrassingly human;
- visual mutation that turns the official into the literal object named in the slogan;
- fake rebrand where the acronym/name mutates into the punchline.

Keep factual-looking political claims clearly satirical unless they are grounded in real, current facts.

## Sok-raka mode

Use this for surreal topical shitposting with a confident editorial voice.

### Core mechanics

- **Category collision:** sport + public health + municipal politics + supermarket promotion, all treated as one natural subject.
- **Faux sincerity:** caption sounds like a normal community post while the visual or premise is rotten.
- **Bait without doctrine:** recognizable topical trigger, but pushed far enough into absurdity that the point is the discourse itself.
- **Anti-branding:** cheap collage, old web graphic, weird crop, ugly type, unearned logo placement.
- **One cursed thesis:** a single nonsensical claim stated with complete confidence.

### Example skeletons

- "[ordinary observation]. dlatego właśnie [wild unrelated conclusion]."
- "Ministerstwo [mundane noun] informuje: [absurd life advice]."
- four unrelated labels arranged as if they form a political spectrum;
- wholesome stock image with a caption that treats it as evidence in an invented national debate.

Do not copy a specific page's wording or recurring catchphrases verbatim.

## Shitpost

Shitpost is not random generation. It is deliberate sabotage of normal meme expectations.

### Reliable devices

- **anti-punchline:** setup promises a reveal; reveal is a mundane object or admin error;
- **semantic derailment:** sentence changes topic mid-thought but lands on one concrete noun;
- **fake lore:** imply a bizarre history everyone supposedly knows;
- **recursive screenshot:** caption comments on a screenshot which contains the caption's premise;
- **overliteral visual:** phrase is rendered physically instead of metaphorically;
- **default-tool aesthetic:** giant Arial/Impact substitute, red arrow, badly drawn circle, WordArt, stretched PNG;
- **compression as punctuation:** visible JPEG rot signals archaeological internet provenance;
- **deliberate typo:** one strategically wrong word can be stronger than five lines of leetspeak.

### Calibration

A strong shitpost has one hidden rule. The audience may not know why the frog is the deputy minister of radiators, but the post behaves as though this is established constitutional law.
