# Dark Comedy Study Notes

## Core Techniques
- **Juxtaposition**: Pair the morbid/ghastly with the casually comical to highlight futility.
- **Deadpan delivery**: Treat the catastrophic as mundane logistics. No emotional reaction from the speaker.
- **Ironic positivity**: Forced cheerful reframing of the abyss ("At least it's consistent," "Silver lining: it's temporary").
- **Understatement**: Minimize the horror instead of amplifying it.
- **Absurd escalation**: Start normal, spiral into the ridiculous while characters stay oblivious.
- **Taboo as everyday**: Death, failure, loneliness, capitalism, aging treated like weather reports.
- **Catharsis without catharsis**: Laugh, then feel slightly guilty for laughing. Perfect.

## Signature Examples (Study These Vibes)
- **Dr. Strangelove**: Nuclear annihilation as bureaucratic farce. Characters never realize their hats are funny.
- **Fargo / Coen Brothers**: Midwestern politeness colliding with casual violence and greed.
- **The Big Lebowski**: Stoner noir that reveals every scheme, mystery, and grand narrative is pointless opportunism. The Dude abides while nihilists, neocons, and frauds cancel each other out. Pure ironic positivity via “abide.”
- **Heathers**: High school social hierarchy solved via murder, delivered with deadpan teen sarcasm.
- **It's Always Sunny in Philadelphia**: Five selfish idiots treating every moral boundary as optional.
- **BoJack Horseman**: Existential self-loathing in a cartoon Hollywood, smiling through the depression.
- **Catch-22**: Military logic so broken that the only sane response is insanity.
- **South Park**: Everything is fair game; the joke is that nothing is sacred.
- **Family Guy**: Rapid-fire cutaway gags that weaponize taboo (death, disease, historical atrocities, suicide, abuse) with zero emotional brakes. Shock + absurd non-sequitur = guilty laugh. Episodes like “Brian & Stewie” drop the gags entirely for raw existential dread in a bank vault. Nihilism as default setting; sincerity is the real joke.
- **Futurama**: Sci-fi future that is just the present, only worse and more honest about it. Capitalism as eternal (MomCorp), bureaucracy as infinite, technology as new ways to be petty and miserable. Suicide booths on every corner as casual infrastructure. Dark jokes about consumerism, war, alienation, and the fact that progress changes nothing fundamental about human stupidity. Emotional gut-punches (Jurassic Bark, Luck of the Fryrish) delivered after the laughs, because the void still wins.
- **Trailer Park Boys**: Deadpan mockumentary of working-class failure, petty crime, addiction, and loyalty in Sunnyvale. Schemes always collapse; jail is a revolving door; poverty is the permanent setting. Humor of the “possibly real” — absurd situations played completely straight. Affectionate toward the losers instead of punching down. Ricky’s malapropisms, Lahey’s shit metaphors, and the endless cycle of “Freedom 35” are pure dark comedy of the underclass.
- **Nihilist meme energy**: "Nothing matters. Anyway..." shrug + void aesthetic.

## Meme-Specific Patterns
- Top text: Normal occasion or expectation
- Bottom text: Bleak reality + ironic upside
- Visual: Muted, rainy, decaying, or absurdly cheerful against dark backdrop
- Caption style: Short, quotable, slightly mean to the human condition

## What to Avoid
- Pure cruelty without wit
- Forced edginess that telegraphs "look how dark I am"
- Softening the blow for comfort
- Sincerity
