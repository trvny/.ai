#!/usr/bin/env node
import { readFile } from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";

const BASE_DIR = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const REGISTRY = path.join(BASE_DIR, "references", "formats.json");
const STOPWORDS = new Set([
  "a", "an", "and", "are", "for", "in", "is", "it", "of", "on", "or", "the", "this", "to", "use", "with",
  "i", "na", "o", "w", "z", "ze", "do", "jak", "meme", "mem", "mema", "memy"
]);

function usage(code = 0) {
  const out = code ? console.error : console.log;
  out(`Usage:\n  formats.mjs list [--json]\n  formats.mjs search <query> [--json]\n  formats.mjs suggest <topic> [--limit N] [--json]`);
  process.exit(code);
}

function parseArgs(argv) {
  const flags = { _: [] };
  for (let i = 0; i < argv.length; i += 1) {
    const arg = argv[i];
    if (!arg.startsWith("--")) { flags._.push(arg); continue; }
    const key = arg.slice(2);
    if (key === "json" || key === "help") flags[key] = true;
    else flags[key] = argv[++i];
  }
  return flags;
}

function normalize(value) {
  return String(value)
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-z0-9]+/g, " ")
    .trim();
}

function tokens(value) {
  return normalize(value).split(/\s+/).filter((x) => x && !STOPWORDS.has(x));
}

function haystack(format) {
  return [format.id, format.name, format.use, format.visual, ...(format.aliases ?? []), ...(format.tags ?? []), ...(format.fields ?? [])].join(" ");
}

function score(format, query) {
  const q = tokens(query);
  const id = normalize(format.id);
  const name = normalize(format.name);
  const aliases = (format.aliases ?? []).map(normalize);
  const tags = (format.tags ?? []).map(normalize);
  const use = normalize(format.use);
  const all = normalize(haystack(format));
  let s = 0;
  for (const t of q) {
    if (id.includes(t)) s += 9;
    if (name.includes(t)) s += 7;
    if (aliases.some((x) => x.includes(t))) s += 6;
    if (tags.some((x) => x.includes(t))) s += 5;
    if (use.includes(t)) s += 3;
    if (all.includes(t)) s += 1;
  }
  return s;
}

const flags = parseArgs(process.argv.slice(2));
if (flags.help) usage(0);
const [command, ...rest] = flags._;
if (!command) usage(1);
const formats = JSON.parse(await readFile(REGISTRY, "utf8"));

if (command === "list") {
  if (flags.json) console.log(JSON.stringify(formats, null, 2));
  else for (const f of formats) console.log(`${f.id}: ${f.name}\n  ${f.use}`);
} else if (command === "search" || command === "suggest") {
  const query = rest.join(" ").trim();
  if (!query) usage(1);
  let ranked = formats
    .map((format) => ({ format, score: score(format, query) }))
    .filter((x) => x.score > 0)
    .sort((a, b) => b.score - a.score || a.format.id.localeCompare(b.format.id));
  if (command === "suggest") ranked = ranked.slice(0, Math.max(1, Number(flags.limit ?? 3)));
  if (flags.json) console.log(JSON.stringify(ranked, null, 2));
  else for (const x of ranked) console.log(`${x.score}\t${x.format.id}\t${x.format.name}\n  ${x.format.use}`);
} else {
  usage(1);
}
