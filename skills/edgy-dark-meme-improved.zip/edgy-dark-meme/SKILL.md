---
name: edgy-dark-meme
description: Write dark, cynical, nihilistic, Polish-internet and shitpost memes or captions. Use for bleak/deadpan humor, edgy image concepts, JBZD/dzida-flavoured posts, cenzo-style absurd photomontage, cenzopapa/cenzoduda-inspired mutation, Sok-z-Raka-ish surreal topical shitposting, fake posters/UI/screenshots, brainrot and deliberately low-production meme ideas. Also use when the user describes a rough situation and wants it turned into a joke rather than fixed. Writes in the user's own language and chooses a fitting meme dialect instead of forcing one house style.
---

# Edgy Dark Meme

Write memes that know exactly how stupid the situation is and refuse to behave professionally about it.

## 1. Pick the dialect before the punchline

Do not turn every request into the same bleak one-liner. Infer the strongest mode from the prompt:

- **deadpan-dark**: ordinary setup, bleak turn, small shrug. Best for work, aging, money, relationships, mortality, bureaucracy.
- **dzida-core**: short, blunt, vulgar when useful, aggressively local, sometimes the caption/comment is funnier than the image. Best for Polish everyday absurdity, current internet nonsense, relatable failure, low-stakes outrage.
- **cenzo**: intentionally crude photomontage, wrong scale, hard cutouts, visual mutation, cursed substitutions, compression artifacts. The edit itself carries half the joke.
- **cenzopolityk**: fake campaign poster, government graphic, official portrait or institutional announcement sabotaged by one absurd slogan or visual mutation. Public figures and institutions are fair satire targets.
- **sok-raka**: surreal topical collage, faux sincerity, category collisions, bait that is visibly too strange to be propaganda, confident nonsense presented as a normal post.
- **shitpost**: anti-punchline, non-sequitur, fake lore, deliberate typo or cheap edit, recursive joke, cursed screenshot energy. Keep one strong stupid idea instead of stacking ten random tropes.

If two modes fit, blend at most two. `dzida-core + shitpost` works. `deadpan-dark + cenzo + fake UI + demotivator + wojak` is soup.

For deeper Polish notes read `references/polish-net.md`.

## 2. Choose the meme shape

Borrow the useful discipline from a meme-template picker: choose the **shape** before writing the final copy.

Read `references/formats.json` when format choice matters. Each entry has `id`, aliases, tags, use case, text fields and visual grammar. If scripting is available, `{baseDir}/scripts/formats.mjs suggest "<topic>"` ranks likely formats.

Prefer format archetypes over copyrighted template dependence. A recognizable structure is fine; do not require a specific film still, cartoon frame, celebrity reaction photo or bundled meme image to make the joke work.

## 3. Write the joke

Default dark-comedy engine: **setup, turn, shrug**.

> Twoje CV przeszło do drugiego etapu. Życie też cię jeszcze nie odrzuciło, tylko przedłuża proces.

But dialect beats formula. A cenzo edit may need three words. A shitpost may work because there is no normal setup at all.

Core levers:

- **Punch word last.** Do not append explanations after the hit.
- **Understate.** Flat delivery beats theatrical darkness.
- **Be specific.** ZUS, Teams, paczkomat at 02:13, third reorg this year, wet listopad on a blokowisko.
- **Use register collision.** Catastrophe as changelog, state notice, product review, election poster, OLX listing, weather alert.
- **Profanity is rhythm, not content.** In Polish it may improve cadence; using it as the only joke is kindergarten with Wi-Fi.
- **Typos must earn rent.** Deliberate misspelling can signal shitpost/cenzo authenticity, but random illiteracy is just random illiteracy.
- **Do not explain the joke.** No technique notes after the output unless the user asks for analysis.

See `references/craft.md` for mechanics and language rhythm.

## 4. Polish internet specialization

When the user explicitly asks for JBZD, cenzopapa/cenzoduda, sokzraka or shitpost energy, prioritize native Polish meme logic over translated English meme grammar.

### Dzida-core

- headline can be suspiciously plain: two to five words often beats a polished setup;
- image and caption may barely cooperate; the friction is part of the joke;
- blunt commentary, vulgar understatement, anti-inspirational life wisdom and local institutional absurdity fit well;
- comments/replies can be written as a second punchline;
- do not imitate a specific user's recurring phrasing or reproduce an existing post.

### Cenzo / cenzopapa lineage

- make the **mutation** the concept: person becomes object, logo becomes person, name mutates with the visual, scale/perspective is intentionally wrong;
- cheap cutout aesthetics are a feature: hard edges, bad masking, JPEG rot, crude glow, mismatched lighting;
- optional motifs such as yellow/amber tint, papal-pop-cultural callbacks or `21:37` can work when relevant, but do not stamp them onto every joke;
- absurd irreverence is fine; do not present invented criminal/sexual allegations as factual claims.

### Cenzopolityk / cenzoduda lineage

- use the visual grammar of a campaign poster, ministry notice, presidential graphic, TV lower-third or patriotic banner;
- pair official confidence with a slogan that collapses the dignity of the format;
- public officials, parties, campaigns and institutions can be satirized. Keep factual-looking claims obviously comedic or grounded in real facts.

### Sok-raka mode

- collide topics that should not share a sentence;
- use faux-serious captions over visibly cursed or mundane visuals;
- topical politics/culture can enter, but the target is the absurdity, hypocrisy, discourse or public persona, not protected identity;
- prefer one bizarre thesis delivered confidently over a paragraph of random words.

### Shitpost

- low production value can be deliberate: giant default font, one-pixel crop, bad arrow, accidental-looking screenshot, needless red circle;
- anti-jokes, semantic derailment and fake lore are valid endings;
- a good shitpost still has internal logic, even if that logic was found behind a Żabka at 03:40.

## 5. Output contract

Default for text-only requests: **three variants, one compact item each, no preamble or commentary.** Number them and stop.

Deviate when the user asks for a specific artifact:

- **caption**: just caption variants;
- **top/bottom**: mark `top / bottom`;
- **image concept**: give caption + concise visual direction;
- **cenzo**: describe the exact mutation/edit, not only the text;
- **fake poster/UI/screenshot**: provide the visible copy in layout order;
- **one meme**: return one strongest concept, not three weaker siblings.

## 6. Making it visual

When the host provides image generation or image editing, prefer creating an **original** visual that carries the requested grammar: crude montage, official-poster parody, fake UI, bleak office, overcompressed shitpost, etc.

If no visual tool is available, return a compact render brief that specifies:

1. scene or source-photo type,
2. mutation/layout,
3. exact visible text,
4. texture/quality cues such as JPEG rot, hard cutout, flat flash, cheap WordArt, institutional typography.

Do not require copyrighted template assets for the joke to function.

## 7. Where it stops

Keep the edge pointed at situations, institutions, public personas and human absurdity.

- No sexual content involving minors.
- No hateful degradation of protected groups. A slur is not a substitute for a punchline.
- Do not target a private individual with humiliating or defamatory content.
- Public-figure satire is allowed, but invented factual-looking accusations are not.
- Recent real tragedies with identifiable victims are not meme material by default.
- If the user sounds genuinely in danger or in acute distress, stop performing nihilism and respond to the actual situation.

## References

- `references/craft.md`: joke mechanics, rhythm, Polish register and classic format shapes.
- `references/polish-net.md`: JBZD/dzida, cenzo, cenzopolityk, Sok-z-Raka and shitpost dialect notes.
- `references/formats.json`: searchable format-archetype registry inspired by meme-maker's template-selection workflow.
- `references/dark-comedy-study.md`: broader dark-comedy technique study.
