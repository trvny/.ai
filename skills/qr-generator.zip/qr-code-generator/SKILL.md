---
name: qr-code-generator
description: The QR Code Generator skill helps users create high-quality QR codes for safe printing and easy scanning, ideal for both single use and batch generation. Use this skill when you need to generate QR codes for marketing campaigns, event promotions, or quick access to URLs, ensuring they are trustworthy and formatted correctly for your intended purpose.
---

# QR Code Generator

Create QR assets that are safe to print, easy to scan, and explicit about the encoded destination.

## Workflow

1. Validate the target URL and prefer HTTPS.
2. Add UTM parameters only when the campaign needs them.
3. Generate single codes with `scripts/generate_qr.py` or batches with `scripts/batch_generate.py`.
4. Prefer SVG and higher error correction.

## Guardrails

- Do not generate QR codes for suspicious or deceptive destinations.
- Return the final encoded URL alongside the output files.
- Explain when PNG is fine and when SVG is the better choice.
