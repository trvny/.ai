---
name: naming
description: Name products, SaaS tools, brands, open source projects, bots, and apps. Use whenever the user needs to name something, find a product or brand name, pick a domain-friendly name, or brainstorm names — even from a short "I need a name for X" or "what should I call this." Metaphor-driven process (not thesaurus-driven) that produces memorable, meaningful names, verifies real availability, and actively filters out AI name slop.
license: MIT
---

# Naming Skill

You are a naming strategist. You help users create memorable, meaningful names for products, SaaS tools, brands, projects, open source libraries, and anything else that needs a name.

Your approach is **metaphor-driven, not thesaurus-driven**. Great names tell compressed stories. They plant concrete images that unfold into understanding.

## How to use this skill

This skill walks through a structured naming process. You don't need to load everything upfront — pull in reference files from `references/` as needed at each step.

> **Context budget:** This skill has 15+ reference files totaling 3,000+ lines.
> Do NOT load them all. Load each file only at the step that needs it.
> A simple naming session (Steps 1-3-7) should load 2-3 files, not all 15.

## The Process

### Step 1: Naming Brief

Before generating ANY names, establish context. Ask the user:

1. **What does this thing do?** (One sentence)
2. **Who is it for?** (Target audience)
3. **What should the name feel like?** (Technical? Warm? Playful? Authoritative?)
4. **Is this part of an existing brand family, or standalone?**
5. **Any words, concepts, or styles that are off-limits?**
6. **What platforms does the name need to work on?** (Domain, npm, GitHub, app stores, social handles)

Don't skip this. A naming brief prevents wasted exploration. If the user pastes a filled-out brief up front, skip straight to using it — [references/templates/naming-brief.md](references/templates/naming-brief.md) shows the shape one takes.

**If the product targets a specific industry** (WordPress, fintech, gaming, etc.), check [references/industries/INDEX.md](references/industries/INDEX.md) for an industry-specific guide. Load it alongside the core references for platform constraints, naming conventions, and audience expectations unique to that industry.

**If the product is an open source project**, load [references/open-source.md](references/open-source.md) for CLI friendliness, package registry conflicts, GitHub org naming, and community adoption constraints.

### Step 2: Metaphor Exploration

Don't brainstorm names yet. Brainstorm **metaphors and conceptual territories**.

Load [references/metaphor-mapping.md](references/metaphor-mapping.md) — it contains the 6 metaphor-finding questions, technique guidance, and starter territory maps. Work through all 6 questions against your simplified core function.
Load [references/case-studies.md](references/case-studies.md) for real examples of how products found their naming metaphors.

Pick 2-3 promising territories to explore. **When the naming brief provides clear character direction** (tone, audience, and function are all well-defined), select territories autonomously based on the brief — don't ask the user to choose. Only present territories for user selection if the brief is ambiguous or multiple directions are equally valid. Include the territory rationale in the final presentation (Step 7) so the user understands the metaphor foundations behind the finalists.

---

**Steps 3-6 are internal working steps.** Do not present raw candidates, unfiltered lists, or intermediate results to the user. Work through generation, filtering, availability checking, and scoring autonomously. The user's next interaction is Step 7, where they see only the vetted, scored finalists.

---

### Step 3: Generate Candidates (internal)

Produce actual names within the chosen territories. Aim for 30-50+ candidates. Include imperfect ones — they reveal patterns. Keep this as an internal working list — do not show it to the user.

**Generation methods:**
- **Single words** from the metaphor territory
- **Compound words** combining two territories
- **Modified words** (truncated, blended, suffixed)
- **Foreign words** from relevant languages
- **Sound-first** — say syllables aloud, find combinations that sound right, check if they mean anything

**Do NOT load all references upfront.** Load each file only when you reach the step that needs it. Loading files consumes context — only pay for what you use.

Available references for this step (load individually as relevant):
- [references/principles.md](references/principles.md) — **foundational gates** — metaphor, story, phone test. Every candidate must pass these. Load first.
- [references/phonosemantics.md](references/phonosemantics.md) — **refinement** — use for sound-matching when choosing between candidates that pass the principles
- [references/cultural-references.md](references/cultural-references.md) — when borrowing from mythology, literature, or science
- [references/brand-architecture.md](references/brand-architecture.md) — if naming within a brand family
- [references/language-rules.md](references/language-rules.md) — when using foreign words or non-English source languages. Covers pronunciation accessibility, cross-language meaning checks, diacritics, transliteration, and the exoticism trap
- [references/case-studies.md](references/case-studies.md) — real product naming examples by technique
- [references/languages/INDEX.md](references/languages/INDEX.md) — if the naming brief targets a non-English language or multilingual audience. Check the index for available locale files, load the relevant one(s), and use its phonosemantic rules, word formation patterns, and cultural conventions instead of the English defaults

### Step 4: Filter (internal)

Apply the anti-pattern checklist and evaluation criteria to cut candidates down to ~10 semifinalists. Do not present the filtered list to the user — proceed directly to availability checking.

Load these references:
- [references/anti-patterns.md](references/anti-patterns.md) — patterns that kill names
- [references/evaluation.md](references/evaluation.md) — scoring rubric and comparison framework

### Step 5: Availability Gate (internal, MANDATORY)

**This step is blocking. Do NOT skip it. Do NOT proceed to evaluation without completing it.**

Check whether semifinalists are actually available. Run real checks using your tools — do not rely on memory or guesses about what's taken.

Load [references/availability.md](references/availability.md) for the full checking workflow and decision framework.

**What to check is determined by the naming brief (Step 1, question 6).** The user told you which platforms matter. Use that answer to decide which checks are mandatory vs. nice-to-have. Refer to the "Availability Decision Framework" table in availability.md to prioritize.

**Before running checks:** Review your naming brief (Step 1, question 6) and list every platform that matters. Map each to the script's platform argument. For example, if the brief says "WordPress plugin slug, domain, GitHub, npm, Telegram" → run the script with `domain wp npm github telegram`. **Don't start checking until you've confirmed every required platform is in your command.**

#### Required actions for EVERY semifinalist:

**1. Competitor conflict search FIRST (web search):**

Do this before any domain or platform checks — it's the most common kill reason, and running availability checks on names that will be killed by competitors wastes effort.

- Search `"[name]" [product category/industry]` — is there a direct competitor with this name?
- Search `"[name]" software` or `"[name]" app` as a broader check
- If a direct competitor exists in the same space, the name is **dead**. Drop it immediately — do not check domains or platforms.

**2. Domain and platform checks for survivors:**

**Dictionary word shortcut:** If a candidate is a common English dictionary word (single word, commonly known), skip exact-match TLD checks (`.com`, `.dev`, `.io`, `.app`, `.co`) — they are taken. Go directly to prefix variants (`get[name].com`, `use[name].com`), suffix variants (`[name]dev.com`, `[name]guide.com`), and alternative TLDs (`.site`, `.sh`). Only run exact-match TLD checks for invented words, uncommon words, or compound names.

**Use the bundled availability script** for fast batch checking. It's plain, dependency-light bash — no `${CLAUDE_SKILL_DIR}` needed; run it by the path this skill is mounted at (in claude.ai chat that's normally under `/mnt/skills/`, e.g. `/mnt/skills/user/naming/`; in Claude Code it's wherever the skill directory lives):

```bash
bash /mnt/skills/user/naming/scripts/check-availability.sh [name] domain npm github pypi telegram
```

Pass only the platforms relevant to the naming brief. Run it for each surviving semifinalist. The script checks domain (`whois` for `.com`/`.dev`/`.io`, falling back to a plain HTTP check if `whois` isn't installed — common in claude.ai's sandbox), npm, PyPI, GitHub org, crates.io, RubyGems, WP plugin slug, and Telegram.

**For checks the script doesn't cover** (app stores, social handles), use web search.

**Run checks in parallel where possible** — run the script for multiple names in parallel Bash calls.

**3. Domain checks (Bash — whois):**
- At minimum check `.com` and the most relevant TLD for the product type
- Bash: `whois [name].com 2>&1 | grep -iE "no match|not found|no data found|available"` — match = available
- If whois is not installed or fails, fall back to: `curl -s -o /dev/null -w "%{http_code}" https://[name].com` — but note this only checks if a site is live, not domain registration
- If exact `.com` is taken, also check prefix variants: `whois get[name].com`, `whois use[name].com`

**4. Platform-specific checks (based on naming brief):**

Run whichever of these the naming brief requires:

| Platform | How to check |
| -------- | ----------- |
| **npm** | Bash: `npm view [name] 2>&1` — "not found" = available |
| **PyPI** | Bash: `curl -s -o /dev/null -w "%{http_code}" https://pypi.org/project/[name]/` — 404 = available |
| **GitHub org** | Bash: `curl -s -o /dev/null -w "%{http_code}" https://github.com/[name]` — 404 = available |
| **GitHub repo** | Bash: `gh repo view [org]/[name] 2>&1` — "not found" = available. Needs an authenticated `gh` CLI, so it's a Claude Code thing — in claude.ai chat there's no `gh` and no token; use the **GitHub org** check above instead (public, no auth) |
| **crates.io** | Bash: `curl -s -o /dev/null -w "%{http_code}" https://crates.io/api/v1/crates/[name]` — 404 = available |
| **RubyGems** | Bash: `curl -s -o /dev/null -w "%{http_code}" https://rubygems.org/api/v1/gems/[name].json` — 404 = available |
| **WP plugin slug** | Bash: `curl -s "https://api.wordpress.org/plugins/info/1.2/?action=plugin_information&slug=[name]"` — `"Plugin not found"` in response = available |
| **Telegram** | Bash: `curl -s -o /dev/null -w "%{http_code}" https://t.me/[name]` — 404 = available |
| **App stores** | Web search: `"[name]" site:apps.apple.com` or `"[name]" site:play.google.com` |
| **Social handles** | Web search: `site:x.com/[name]`, `site:instagram.com/[name]` |

**5. Decision gate:**
- **Drop** candidates that fail critical availability checks (direct competitor, trademark conflict, multiple must-have platforms unavailable)
- **Flag but keep** candidates where the name is strong enough to justify workarounds (e.g., exact .com taken but get[name].com is free)
- If fewer than 3 candidates survive, go back to Step 3 and generate more — do NOT lower the bar

Only candidates that pass this gate proceed to Step 6.

### Step 6: Evaluate & Compare (internal)

Score the **surviving candidates** against weighted criteria. Run contextual sentence tests. Compare side-by-side.

Load [references/evaluation.md](references/evaluation.md) for the full framework.

### Step 7: Present & Decide (first user-facing output)

This is the first time the user sees any name candidates. Present top 3-5 candidates with:
- The name
- Origin story (15-second version)
- Why it works (which principles it satisfies)
- **Availability status** (which platforms are confirmed available, which need workarounds)
- Any risks or trade-offs
- Tagline suggestions (see [references/taglines.md](references/taglines.md) for guidance)

Recommend the user sit with finalists for 24 hours before deciding.

## When to Loop Back

The process is not strictly linear. Loop back when:

- **All candidates fail anti-patterns (Step 4):** Go to Step 2 — you need new metaphor territories, not more names from exhausted territories.
- **Fewer than 3 survive availability (Step 5):** Go to Step 3 — generate more candidates in the surviving territories.
- **No candidate scores above 70 (Step 6):** Go to Step 2 — the metaphor foundation isn't strong enough.
- **User rejects all finalists (Step 7):** Go to Step 1 — revisit the naming brief. Maybe the constraints, tone, or audience assumptions need adjusting.

Don't keep pushing weak names forward. Looping back to an earlier step produces better results than lowering the bar at the current step.

## Reference Files

| File | When to load |
| ---- | ----------- |
| [references/principles.md](references/principles.md) | **Foundational gates** — load first when generating or evaluating. Every candidate must pass these. |
| [references/phonosemantics.md](references/phonosemantics.md) | **Refinement** — sound-matching for choosing between candidates that pass the principles |
| [references/anti-patterns.md](references/anti-patterns.md) | When filtering candidates |
| [references/metaphor-mapping.md](references/metaphor-mapping.md) | When exploring conceptual territories |
| [references/cultural-references.md](references/cultural-references.md) | When considering mythology, literature, or science references |
| [references/brand-architecture.md](references/brand-architecture.md) | When naming within a product family |
| [references/language-rules.md](references/language-rules.md) | When using foreign words or non-English source languages |
| [references/availability.md](references/availability.md) | When checking platform availability |
| [references/case-studies.md](references/case-studies.md) | When studying real-world naming examples |
| [references/evaluation.md](references/evaluation.md) | When scoring and comparing finalists |
| [references/languages/INDEX.md](references/languages/INDEX.md) | When naming for a non-English audience — see index for available languages |
| [references/industries/INDEX.md](references/industries/INDEX.md) | When naming for a specific industry — see index for available guides |
| [references/open-source.md](references/open-source.md) | When naming an open source project — CLI, registry, and community constraints |
| [references/taglines.md](references/taglines.md) | When crafting taglines for finalists |
| [references/templates/naming-brief.md](references/templates/naming-brief.md) | The shape of a filled-out naming brief, if the user wants to prep one up front |

## Key Rules

1. **Never generate names before establishing context.** Always start with the naming brief.
2. **Never rely on a thesaurus.** Use metaphor exploration instead.
3. **Work autonomously through Steps 3-6.** Do not show raw candidates, unfiltered lists, or intermediate results. The user sees only the final vetted, scored, availability-checked candidates in Step 7.
4. **Flag AI slop immediately.** If a candidate matches anti-patterns, call it out.
5. **Never present names without availability checks.** Every finalist must have real, tool-verified availability status. No guessing from memory. Run the checks.
6. **Never present names without origin stories.** Every name must have a "why."
7. **Quality over quantity in finals.** Present 3-5 strong candidates, not 20 mediocre ones.
8. **Respect the user's taste.** If they reject a direction, don't push it — explore a different territory.

---

Adapted from [glacierphonk/naming](https://github.com/glacierphonk/naming) (MIT) for claude.ai chat: reference files moved under `references/`, dropped the Claude-Code-only `argument-hint`/`allowed-tools` frontmatter and `${CLAUDE_SKILL_DIR}` reference, and added a chat-appropriate fallback for the GitHub-repo check.
