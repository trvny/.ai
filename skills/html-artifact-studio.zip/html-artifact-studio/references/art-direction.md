# Art direction reference

Load this only when visual direction is genuinely open-ended or the current result feels generic.

## Pick a register before a style

Classify the artifact's dominant register:

- **utility**: task speed, clarity, control density;
- **editorial**: reading rhythm, narrative, hierarchy;
- **brand/product**: identity, persuasion, memorable product signal;
- **data**: comparison, trend, anomaly, annotation;
- **playful/experiential**: manipulation, motion, surprise;
- **poster/graphic**: composition and visual impact.

Mix registers intentionally. A utility app may have editorial typography, but it should not bury the task under a landing-page costume.

## Build a direction from four decisions

### 1. Mood
Choose concrete adjectives that imply visual consequences.

Better: `clinical, compact, nocturnal`
Worse: `modern, clean, premium`

### 2. Composition
Choose a dominant spatial idea:

- asymmetric editorial grid;
- centered stage;
- split-pane workspace;
- horizontal rails;
- dense control matrix;
- full-bleed image with restrained overlay;
- typographic poster;
- timeline or sequence;
- open canvas with anchored controls.

### 3. Typography
Assign jobs, not merely fonts:

- display voice;
- reading voice;
- UI/control voice;
- numeric/data voice when needed.

Favor contrast in role. A characterful display face paired with a quiet body face is often stronger than four similar weights of one family.

If external fonts are unavailable, choose fallbacks that preserve the intended category and proportions.

### 4. Signature move
Choose one memorable device:

- rule-and-label rhythm;
- clipped/offset media frame;
- oversized index numbers;
- moving baseline/ticker;
- unusual but legible navigation placement;
- subtle paper/noise texture;
- spatial transition;
- reactive cursor/canvas;
- strong typographic crop.

The signature move should support the product, not become a theme park.

## Palette method

Start with roles:

`background → surface → text → muted → border → accent → semantic`

Then choose actual colors.

Strong palettes usually have a dominant temperature and one counterpoint. Avoid distributing five saturated colors evenly.

Use gradients only when they explain light, depth, progression, atmosphere, or brand identity. “Because gradients look futuristic” is not a reason.

## Layout test

Before polishing, answer:

- Where does the eye land first?
- What is second?
- What can be ignored?
- What changes at mobile width?
- What is the one visual feature someone might remember tomorrow?

If these answers are fuzzy, the design is not ready for decoration.

## Anti-template repair

When a page feels generated:

1. remove half the containers;
2. replace generic centered sections with a stronger composition;
3. simplify the palette;
4. increase typographic contrast;
5. make copy more specific;
6. remove decorative metrics/badges;
7. choose one signature detail;
8. check whether imagery would communicate better than more UI chrome.
