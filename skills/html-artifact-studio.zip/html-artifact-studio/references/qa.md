# Rendered QA reference

Use this before final handoff when browser/screenshot tooling is available, or as a manual checklist otherwise.

## Hard failures

Fix before shipping:

- clipped or overlapping primary content;
- horizontal overflow on a normal mobile viewport;
- unreadable contrast;
- missing visible focus;
- keyboard-inoperable primary flow;
- buttons/links that look active but do nothing;
- missing labels on forms;
- critical information available only on hover;
- broken images, icons, fonts, or console errors;
- accidental text wrapping that changes the composition;
- mobile that is merely a squeezed desktop;
- placeholder or lorem-ipsum content left behind;
- fake controls, fake progress, or fake state presented as functional;
- giant empty areas caused by fixed heights;
- card soup with no information hierarchy;
- browser-default typography leaking into controls;
- motion that ignores reduced-motion preference.

## Visual inspection pass

### Hierarchy
Can a new viewer identify the purpose, primary action, and next most important information within seconds?

### Composition
Does the page have a deliberate focal point and rhythm, or does every block shout equally?

### Typography
Check heading scale, body line length, line-height, labels, controls, numbers, and mobile line breaks.

### Color
Check background/surface relationships, muted text, borders, semantic states, and accent scarcity.

### Components
Repeated elements should share geometry, spacing, icon treatment, and interaction states unless the difference is intentional.

### Responsive
Check wide/desktop, ordinary laptop/tablet if relevant, and narrow/mobile. Look for recomposition, not only shrinking.

### Interaction
Exercise the main path. Verify focus, hover, active, selected, disabled, success/error, and persistence behavior where relevant.

## Final repair loop

For every visible issue:

`evidence → cause → smallest durable fix → rerender`

Prefer fixing the system/token/component that caused the problem instead of patching one element.

Stop only when another design review would be discussing taste-level refinements rather than obvious defects.
