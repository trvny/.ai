---
name: html-artifact-studio
description: Build or substantially redesign polished HTML artifacts, standalone webpages, mini apps, dashboards, visual explainers, interactive demos, posters, calculators, and HTML/CSS/JS prototypes. Use when the user wants a web artifact that should feel distinctive, production-grade, responsive, accessible, and fully functional rather than template-like or generically AI-styled. Also use to beautify or repair an existing HTML artifact when visual hierarchy, interaction quality, responsiveness, or design coherence is a major part of the task.
---

# HTML Artifact Studio

Create web artifacts that feel art-directed, not auto-completed.

The target is not maximum decoration. The target is a clear idea, a coherent visual system, working interaction, and a rendered result that survives close inspection.

## Workflow

### 1. Read the surface before styling it

Establish from the request and available files:

- what the artifact is for;
- who uses it and what they should understand or accomplish;
- the content and controls actually required;
- whether this is a standalone file, embedded artifact, or existing app surface;
- implementation constraints such as offline use, no dependencies, framework, assets, or target viewport.

When modifying an existing artifact, inspect its typography, spacing, components, tokens, icon family, interaction patterns, and build conventions first. Extend the existing design language unless the user explicitly wants a redesign.

Do not invent product claims, metrics, testimonials, navigation, or fake data merely to fill space.

### 2. Commit to one visual thesis

Before implementation, settle on one sentence that combines:

`mood + composition + typography + signature move`

Examples of the shape, not presets:

- quiet editorial utility with asymmetric columns, literary type, and hairline rules;
- dense technical cockpit with crisp monospace labels, layered rails, and one luminous status accent;
- playful tactile toy with chunky geometry, oversized type, and springy direct manipulation.

The direction should be specific to the task. Use one or two memorable motifs, not a sack of unrelated tricks.

Read `references/art-direction.md` when the brief is visually open-ended, when the artifact feels generic, or when typography/layout/palette is the hard part.

### 3. Lock a tiny design system

Define the system before sprinkling values through CSS.

At minimum establish:

- background, surface, text, muted text, border, accent, and semantic colors;
- display/body type roles and a deliberate type scale;
- spacing rhythm;
- container width and layout grid;
- radius, border, and shadow logic;
- motion timings/easing;
- responsive breakpoints only where the composition actually changes.

Use CSS custom properties for repeated values. Prefer a few strong decisions over many weak ones. Two type families and two accent hues are usually plenty. Avoid one-off measurements when a scale can explain them.

### 4. Build the real artifact

For portable standalone deliverables, prefer semantic HTML + CSS + JavaScript with no runtime dependency unless a library materially improves the result.

For repo work, follow the existing stack instead of replacing it.

Requirements:

- keep interface text, controls, tables, forms, and navigation code-native;
- use semantic elements before ARIA patches;
- use real buttons for actions and links for navigation;
- every interactive control must actually work;
- model loading, empty, error, selected, disabled, and success states when the workflow needs them;
- preserve user data locally only when useful and non-sensitive;
- use SVG or the existing icon set for interface icons; do not use emoji as generic UI glyphs;
- use images or generated artwork when imagery is central to the concept, but do not rasterize the interface itself;
- keep central content above decorative chrome.

For charts and visual explanations, optimize for the takeaway first. Labels, scale, annotation, and contrast matter more than chart ornament.

### 5. Compose instead of card-stacking

Do not default every section to a rounded rectangle.

Choose containers because the information model needs them. Consider open whitespace, bands, rails, split panes, lists, tables, canvases, timelines, full-bleed media, or editorial columns before reaching for another card grid.

Vary rhythm deliberately on long surfaces. Repeating the same centered heading + three cards pattern is a smell.

### 6. Spend delight where it compounds

One well-orchestrated moment beats twenty unrelated animations.

Good places for motion:

- entrance hierarchy;
- direct manipulation;
- state transitions;
- progress;
- spatial continuity;
- a single signature interaction.

Keep hover, focus, active, selected, and pressed states intentional. Respect `prefers-reduced-motion`.

If motion adds latency, ambiguity, or visual noise, delete it.

### 7. Keep the AI starter pack out

Unless the brief explicitly calls for them, avoid stacking these defaults:

- purple/cyan gradient-on-dark;
- floating blurred glow orbs;
- glassmorphism on every surface;
- giant rounded bento-card grids;
- tiny pill or eyebrow above every heading;
- huge centered marketing headline plus vague subtitle;
- Inter/system-ui everywhere by reflex;
- fake analytics, fake testimonials, or decorative metrics;
- random gradient text;
- excessive shadows and 24px radii;
- generic sparkles, rockets, brains, magic wands, or emoji-as-icons;
- empty “premium” copy that says nothing specific.

Any one of these can be valid. The failure mode is using several automatically because no design direction was chosen.

### 8. Accessibility and responsive behavior are hard gates

Ship only interfaces that remain usable beyond the ideal screenshot.

Check:

- logical heading order and landmarks;
- visible keyboard focus;
- full keyboard operation for meaningful flows;
- associated labels and useful error messages;
- sufficient text and control contrast;
- no meaning conveyed by color alone;
- comfortable touch targets on mobile;
- no hidden critical action that exists only on hover;
- zoom and long-content resilience;
- `prefers-reduced-motion`;
- layouts that recompose on narrow screens rather than merely shrink.

Treat mobile as another composition state, not a scaled desktop.

### 9. Render, inspect, and repair

A build passing is not visual QA.

When browser or screenshot tooling is available:

1. render the artifact;
2. inspect the first viewport and the full page/surface;
3. exercise the core interaction path;
4. check at least one narrow/mobile viewport;
5. inspect keyboard focus and overflow;
6. check console errors and failed assets;
7. compare the render against the intended visual thesis and fix visible drift.

Read `references/qa.md` for the final gate and hard-failure list.

Do not hand off a visibly unfinished artifact just because the HTML is valid.

## Surface heuristics

### Utility / mini app
Put the tool first. Avoid wrapping a small useful interaction in a fake SaaS homepage.

### Dashboard / data-heavy UI
Preserve density. Tables, rows, filters, timelines, and split panes often communicate better than cards.

### Landing / product page
Make the promise, proof, and primary action obvious. Avoid invented social proof and decorative dashboards.

### Editorial / explainer
Let typography, pacing, imagery, annotation, and whitespace carry the hierarchy.

### Poster / expressive artifact
Allow stronger graphic composition, but keep text selectable/readable when practical and preserve a semantic fallback.

### Existing design system
Reusing the product's real tokens and components outranks introducing a prettier parallel system.

## Tool coordination

Use available tools when they improve fidelity:

- use image generation for central artwork, hero imagery, textures, illustrations, or visual assets, not for interactive UI text;
- use source images when the task depends on a real person, place, product, or supplied reference;
- use browser/screenshot tools for rendered QA;
- use repository inspection before introducing frameworks, icon libraries, or component systems.

Do not block useful implementation just because an optional tool is unavailable. Use a clean fallback and keep the artifact self-contained when possible.

## Completion bar

The artifact is done when all are true:

- the purpose and hierarchy are obvious;
- the visual direction is recognizable in one glance;
- repeated styling follows a small coherent system;
- interactions and relevant states work;
- desktop and narrow layouts are intentional;
- accessibility has no obvious hard failure;
- the rendered result has been inspected when tooling permits;
- there is no generic filler or ornamental debris you would remove in a design review.
