# Craft Reference

Three sections: **Mechanics** (how the joke is built), **Format library** (the shapes it goes in), **Polish register** (what changes when the request is in Polish).

---

## Mechanics

### The turn
Every dark joke is one sentence that changes meaning halfway. Techniques for the pivot:

- **Literalism.** Take a comforting cliche at face value until it collapses. "Live every day like it's your last" -> "so, panicking and calling relatives."
- **Bureaucratic framing.** Treat catastrophe as an admin task with a form and a queue number. Strangelove's whole engine.
- **Scale collapse.** Put the cosmic and the petty in the same sentence, weight them equally. "The universe is expanding and so is my overdraft."
- **False comfort.** Offer reassurance that makes it worse on inspection. "Nobody's judging you. Nobody's thinking about you at all."
- **Category error.** Describe a feeling with the vocabulary of something mundane — weather reports, product reviews, changelogs, error messages. "Loneliness, 4/5 stars, arrived early."
- **Delayed reveal.** The first half is sincere. The last two words aren't.

### Rhythm
- Rule of three, where the third breaks the pattern rather than extending it.
- Short-short-long, or long-long-short. Never three equal-length clauses; it reads as a list, not a joke.
- Cut every adverb. "Slowly dying" is weaker than "dying."

### Calibration
- If it could appear on a motivational poster with one word changed, it isn't dark enough.
- If the reader has to be told it's a joke, it isn't a joke.
- If it works equally well about anything, it's too generic — put a specific noun in it.

---

## Format library

**Top / bottom text.** Top = the normal expectation, bottom = the bleak reality plus the shrug. The workhorse. Both halves under ~8 words.

**Object labeling.** Three labeled entities in a scene: the thing you want, the thing you get, and the thing that was always going to win. Label copy should be flat and clinical.

**Two buttons.** Sweating person, two buttons, both terrible, no third option. The joke is that the choice is fake.

**Expanding brain.** Four escalating "insights" where each is dumber or bleaker than the last while the visual grows more cosmic. Escalate the *confidence*, not the wisdom.

**Drake / this-not-that.** Reject the healthy option, embrace the self-destructive one. Works best when the rejected option is something genuinely good advice.

**Wojak / doomer.** First-person confession, deadpan, present tense, no self-pity. The lack of self-pity is what makes it funny rather than sad.

**Deadpan tweet.** No image at all. One or two flat sentences, lowercase, no punchline signposting. Often the strongest form for a bleak caption on a real situation the user just described.

**Fake product / UI copy.** Error dialogs, terms of service, app store descriptions, changelog entries for a life. "v34.0 — removed several friends, performance unchanged."

**Motivational poster inversion.** Full corporate visual grammar (serif caption, sunset, mountain) with a caption that reads as encouragement only until the second pass.

---

## Polish register

Polish dark humour is a different tradition, not a translation target. Load-bearing differences:

- **Understatement is already the default.** Polish everyday speech is drier than English, so the deadpan needs to be even flatter — pushing the "look how bleak" pedal reads as *cringe*, not as dark.
- **The material is domestic and institutional.** ZUS, PIT, NFZ kolejka, korpo-mowa and the endless reorg, Januszex employers, blokowisko in November, the Fiat 126p as a symbol of aspirational misery, "jakoś to będzie" as national coping doctrine.
- **Registers to draw on:** *sucharek* (deliberately terrible pun, funny because it's terrible — signal with a straight face, never with "haha"), *pasta* (long deadpan first-person copypasta, escalating absurdity, told completely straight), jbzd/karachan-flavoured bleakness, PRL nostalgia used ironically.
- **Diminutives are a weapon.** Polish shrinks nouns for affection; shrinking a horrible noun ("egzekucyjka", "zawałek") is a native comic move with no clean English equivalent.
- **What doesn't survive translation, either way:** English absurdist non-sequitur often lands flat in Polish; Polish institutional gallows humour loses all its teeth in English because the referent means nothing. Rebuild the joke in the target language rather than porting it.
- **Profanity is ordinary punctuation** in casual Polish, not a shock device. Use it as rhythm, not as the punchline.

Write Polish memes in Polish word order and Polish sentence music. If a draft could be reverse-translated to English word-for-word and still parse cleanly, it's probably an English joke in disguise.

---

## Dialect selection

Before using the classic format library, decide whether the request is better served by `deadpan-dark`, `dzida-core`, `cenzo`, `cenzopolityk`, `sok-raka`, `shitpost`, `pepe-climate`, `vibe-swagger`, `kajmak`, `nosacz-cast`, `demot`, `pasta`, or `suchar`. See `polish-net.md`. Format follows dialect, not the other way around.
