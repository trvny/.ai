# Polish Internet Meme Dialects

This reference captures reusable mechanics, not exact replicas of existing pages or creators.

## JBZD / dzida-core

### What carries the joke

- **Low ceremony.** The title may be two blunt words. The image does not need a polished setup.
- **Comment-as-punchline.** A dry reply, correction or insult to the situation can outperform the post itself.
- **Local nouns.** Polska B, blok, urząd, paczkomat, Żabka, Januszex, działka, Passat, NFZ, ZUS, OLX, osiedlowy monitoring, sebix logistics.
- **Fast topical mutation.** Current news becomes a format immediately, often without waiting for a canonical template.
- **Crude confidence.** The post does not apologize for bad cropping, bad grammar or low resolution when those traits help the bit.

### Strong shapes

- ordinary photo + one-line hostile observation;
- screenshot + highlighted absurdity + caption;
- fake advice/tutorial where the advice is technically possible and spiritually catastrophic;
- title that undersells a ridiculous image;
- image + second-stage comment punchline.

### Avoid

- trying too hard to sound "internet";
- ten layers of slang in one sentence;
- replacing the joke with pure contempt for a demographic;
- polishing away the accidental/cheap texture that makes the format work.

## KIEDY:

The 2010s Polish image-macro that never died. Impact, all caps, colon.

1. `KIEDY [household / dad / school / work situation]:`
2. A found photo that is already the punchline — road sign, receipt, shop window, misspelled menu.
3. Stop. Do not explain the sign.

Dad dictating a shopping list that becomes `Pisz 11 / Łomza 72` is the whole climate. Relatable setup, object does the joke, comment under it is just `czujesz`.

Blend with dzida or nosacz-cast. Do not invent a new religion around one road sign.

## Cenzo

Cenzo is mutation humor. The visual edit is not illustration for the caption; it is the joke's main verb.

### Mutation engine

1. Identify the subject's most recognizable visual or lexical feature.
2. Replace it with something semantically nearby, phonetically similar or completely inappropriate.
3. Make the visual substitution literal.
4. Rename/re-caption the subject to match the mutation.
5. Leave the edit slightly too crude to look official.

Useful mutation types:

- head/object swap;
- body becomes product/vehicle/food/tool;
- logo/name phonetic mutation;
- historical/religious/state imagery inserted into banal modern context;
- tiny person in huge object or huge face in tiny frame;
- deliberately mismatched perspective and lighting.

### Texture

Hard cutout, wrong white balance, JPEG blocks, cheap glow, visible scaling artifacts, old forum/imageboard energy. Clean professional compositing can actually make cenzo less funny.

### Cenzopapa lineage

Use as a cultural grammar of irreverent mutation, not as a requirement to reproduce old allegations or exact legacy posts. Papal visual callbacks, yellow/amber tint and `21:37` can be optional seasoning when the request points there.

## Cenzopolityk

Generalized from cenzoduda-style political edits.

### Visual grammar

- campaign billboard;
- official presidential portrait;
- ministry/public-service announcement;
- patriotic red-white banner;
- TV news lower-third;
- ballot or referendum graphic;
- municipal poster or state-company ad.

### Joke engine

The format promises dignity and authority. The caption removes both.

Best turns:

- absurdly small promise framed as historic achievement;
- slogan that accidentally admits the real motive;
- bureaucratic wording describing something embarrassingly human;
- visual mutation that turns the official into the literal object named in the slogan;
- fake rebrand where the acronym/name mutates into the punchline.

Keep factual-looking political claims clearly satirical unless they are grounded in real, current facts.

## Sok-raka mode

Use this for surreal topical shitposting with a confident editorial voice.

### Core mechanics

- **Category collision:** sport + public health + municipal politics + supermarket promotion, all treated as one natural subject.
- **Faux sincerity:** caption sounds like a normal community post while the visual or premise is rotten.
- **Bait without doctrine:** recognizable topical trigger, but pushed far enough into absurdity that the point is the discourse itself.
- **Anti-branding:** cheap collage, old web graphic, weird crop, ugly type, unearned logo placement.
- **One cursed thesis:** a single nonsensical claim stated with complete confidence.

### Example skeletons

- "[ordinary observation]. dlatego właśnie [wild unrelated conclusion]."
- "Ministerstwo [mundane noun] informuje: [absurd life advice]."
- four unrelated labels arranged as if they form a political spectrum;
- wholesome stock image with a caption that treats it as evidence in an invented national debate.

Do not copy a specific page's wording or recurring catchphrases verbatim.

## Shitpost

Shitpost is not random generation. It is deliberate sabotage of normal meme expectations.

### Reliable devices

- **anti-punchline:** setup promises a reveal; reveal is a mundane object or admin error;
- **semantic derailment:** sentence changes topic mid-thought but lands on one concrete noun;
- **fake lore:** imply a bizarre history everyone supposedly knows;
- **recursive screenshot:** caption comments on a screenshot which contains the caption's premise;
- **overliteral visual:** phrase is rendered physically instead of metaphorically;
- **default-tool aesthetic:** giant Arial/Impact substitute, red arrow, badly drawn circle, WordArt, stretched PNG;
- **compression as punctuation:** visible JPEG rot signals archaeological internet provenance;
- **deliberate typo:** one strategically wrong word can be stronger than five lines of leetspeak.

### Calibration

A strong shitpost has one hidden rule. The audience may not know why the frog is the deputy minister of radiators, but the post behaves as though this is established constitutional law.

## Pepe-climate

Pepe here is a reaction mascot grammar, not a political uniform.

### Moods that actually work

- **sad / feels-bad** — the situation already happened; the frog is the aftertaste.
- **smug** — thumb-under-chin, I-told-you-so without a speech.
- **salute** — duty, fake patriotism, joining a bit too late.
- **flag overlay** — frog wearing a national or faction costume. The joke is the costume, not a recruitment poster.
- **deal-with-it shades** — no comment required; the glasses are the caption.
- **punch / point at camera** — the viewer is the problem.

### Visual rules

- original green anthropomorphic frog, thick outlines, flat color, huge wet eyes;
- one pose, one overlay, one caption max;
- cheap PNG-on-flag compositing is allowed and often funnier than a clean render;
- do not require a specific copyrighted Pepe still. Recreate the pose.

### Avoid

- using the frog as a hate-symbol delivery vehicle;
- stacking rare-pepe lore, Kek cosmology and three flags in one frame;
- writing a paragraph under a face that already finished the joke.

## Vibe-swagger / vibe-codeswag

Two skins of the same joke.

**Swagger skin** — product mark that thinks it is a guy. Pixel sunglasses, white pointing gloves, radial burst. Caption as a victory lap. The win is pathetic.

**Codeswag skin** — "Claude and I" / "Grok and I" as a duo. Human is the product manager. Model is the co-founder who never sleeps and never reads the diff. Accept All. Paste the stack trace back in. Ship to Vercel. Tokens end mid-feature. Production is held together by markdown files the agent wrote about itself.

### Engine

1. Pair the user with a named model as if they are a band.
2. Give the pair unearned cool.
3. Let the deliverable be 4,000 lines, 0 tests, 47 dependencies, one README that says "enterprise-ready."
4. Keep the tone proud. The horror is in the inventory.

### Register

- English swagger can stay English inside a Polish post (`we ball`, `just shipped`, `you're absolutely right`, `Claude and I`).
- Polish is drier — "wyjebało", "leci", "ogarnięte", "wypuściliśmy".
- `motherfucker` is percussion. One per concept.

### Strong shapes

- logo + deal-with-it glasses + two pointing hands (the Claude-sunburst pose);
- **Claude-and-I jam** — two guys at a laptop + mini-keyboard. Model wears the pixel-face mark. Human is labeled `ME`. Model plays. Human hypedances, points, almost cries. Both sprint at camera. End card: `SHIPPED APP`. Audio can be just "conk conk";
- "Claude and I" caption over a burning local repo;
- fake PR "feat: add entire business, lgtm";
- changelog "v∞ — added swagger, removed meaning";
- token-limit tombstone in the middle of a feature.

### Jam grammar

Roles stay fixed. Model is the taller silent virtuoso. Human is the hype man who cannot play. The instrument is a laptop. The finish line is an app nobody reviewed. Rebuild the blocking — two bodies, one keyboard, one label, one sprint — do not depend on a specific studio clip.

## Kajmak

Extracted from the irregular Polish "śmieszne obrazki a może nieśmieszne" page climate. Do not copy their recurring characters or exact lines.

### Voice

- lowercase, spoken to the boys, posted when the admin felt like it;
- captions undersell — object vs owner, archive dump, beer, slightly broken spelling;
- the image may be older than the joke and look found, not produced;
- comments in the same register can finish the bit.

### Visual

- cheap collage, random stock, old cartoon still, food, tools, animals, medieval junk, cars;
- compression and bad crop are texture;
- #mem #piwo energy — domestic, not editorial.

### Joke engine

Everyday noun becomes opponent, relic or legend. The poster does not explain why the tin can is venomous. The audience is already in the trailer.

## Nosacz-cast

Polish household sitcom that never got a network. Names are masks for behaviors.

- **Janusz** — saving 40 groszy, grilling in a winter jacket, jealous of the somsiad, "Niemiec płakał jak sprzedawał."
- **Grażyna** — Lidl haul, kuboty, family logistics, all-inclusive audit.
- **Seba / sebix** — parking-lot drift, patriotic hoodie, kebab geopolitics at a bus stop.
- **Dżesika / Karyna / Pioter / Brajan** — next generation of the same house.
- **Januszex** — the boss who invented unpaid overtime and called it flexibility.

Write the habit, not "look a monkey." An original middle-aged guy in sandały + skarpety is enough. Seasonal skins reset every year — parawaning, grill-w-marcu, wczasy all inclusive.

Target the combo, not an entire class as a slur.

## Demot

Older than dzida and still walking.

- thick black frame, centered photo, two-line caption hierarchy;
- title sounds like a proverb; subtitle removes the air;
- PRL nostalgia, failed adulthood, "kiedyś to było," workplace martyrdom.

## Pasta

Long deadpan monologue. The speaker never admits it is a joke.

- start ordinary — Żabka shift, fishing, family dinner;
- escalate one extra object or claim per paragraph;
- keep grammar almost formal;
- stop one beat after the reader should have left.

## Suchar

A pun so bad it becomes furniture. One sentence. If you write "haha suchar" you already lost.

## Platform weather

- **JBZD / dzida** — blunt, local, comment can beat the post.
- **Kwejk** — recycled lol, tags, lowest-effort share.
- **Demotywatory** — framed melancholy and uncle wisdom.
- **Wykop** — news-as-fight, faction posting, screenshot wars.
- **Karachan / vichan** — imageboard sludge and pasta. Wojak started here as a sad bald Polish guy before the world hired him.

Use the weather. Do not impersonate a specific admin.
