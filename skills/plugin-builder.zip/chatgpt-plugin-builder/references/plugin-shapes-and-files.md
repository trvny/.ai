# Plugin shapes and files

## Skills only

```text
plugin-name/
├── .codex-plugin/
│   └── plugin.json
└── skills/
    └── workflow-name/
        └── SKILL.md
```

Manifest includes `"skills": "./skills/"`.

## Registered MCP connection

```text
plugin-name/
├── .codex-plugin/
│   └── plugin.json
└── .app.json
```

Manifest uses compatibility field `"apps": "./.app.json"`.
`.app.json` maps a connection already registered through the supported
ChatGPT flow. Do not invent technical IDs.

## Bundled MCP server

```text
plugin-name/
├── .codex-plugin/
│   └── plugin.json
└── .mcp.json
```

Manifest includes `"mcpServers": "./.mcp.json"`.

## Combined

A plugin may include skills, `.app.json`, `.mcp.json`, assets, and hooks.
Keep only `plugin.json` inside `.codex-plugin/`.
