#!/usr/bin/env python3
"""Scaffold a minimal ChatGPT/Codex plugin folder."""

from __future__ import annotations

import argparse
import json
import re
from pathlib import Path

NAME_RE = re.compile(r"^[a-z0-9]+(?:-[a-z0-9]+)*$")
VERSION_RE = re.compile(r"^\d+\.\d+\.\d+(?:[-+][0-9A-Za-z.-]+)?$")


def require_name(value: str) -> str:
    if not NAME_RE.fullmatch(value):
        raise argparse.ArgumentTypeError("expected lowercase kebab-case")
    return value


def require_version(value: str) -> str:
    if not VERSION_RE.fullmatch(value):
        raise argparse.ArgumentTypeError("expected a semantic version such as 0.1.0")
    return value


def write(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding="utf-8")


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("output_dir", type=Path)
    parser.add_argument("--name", required=True, type=require_name)
    parser.add_argument("--description", required=True)
    parser.add_argument("--version", default="0.1.0", type=require_version)
    parser.add_argument("--skill", action="append", type=require_name)
    parser.add_argument("--registered-app-id")
    parser.add_argument("--bundled-mcp-name", type=require_name)
    parser.add_argument("--command")
    parser.add_argument("--force", action="store_true")
    args = parser.parse_args()

    root = (args.output_dir / args.name).resolve()
    if root.exists() and any(root.iterdir()) and not args.force:
        parser.error(f"refusing to overwrite non-empty directory: {root}")
    root.mkdir(parents=True, exist_ok=True)

    skills = args.skill or []
    manifest: dict = {
        "name": args.name,
        "version": args.version,
        "description": args.description.strip(),
        "interface": {
            "displayName": args.name.replace("-", " ").title(),
            "shortDescription": args.description.strip()[:100],
        },
    }

    if skills:
        manifest["skills"] = "./skills/"
        for skill_name in skills:
            write(
                root / "skills" / skill_name / "SKILL.md",
                (
                    "---\n"
                    f"name: {skill_name}\n"
                    f"description: TODO: describe the workflow and when {skill_name} should activate.\n"
                    "---\n\n"
                    f"# {skill_name.replace('-', ' ').title()}\n\n"
                    "Define expected input, workflow, output, boundaries, and stop rules.\n"
                ),
            )

    if args.registered_app_id:
        if not args.registered_app_id.startswith("plugin_asdk_app"):
            parser.error("--registered-app-id should come from the supported ChatGPT registration flow")
        manifest["apps"] = "./.app.json"
        write(
            root / ".app.json",
            json.dumps(
                {"apps": {args.name: {"id": args.registered_app_id}}},
                indent=2,
            ) + "\n",
        )

    if args.bundled_mcp_name:
        if not args.command:
            parser.error("--command is required with --bundled-mcp-name")
        manifest["mcpServers"] = "./.mcp.json"
        write(
            root / ".mcp.json",
            json.dumps(
                {
                    args.bundled_mcp_name: {
                        "command": args.command,
                        "args": [],
                    }
                },
                indent=2,
            ) + "\n",
        )

    write(
        root / ".codex-plugin" / "plugin.json",
        json.dumps(manifest, indent=2) + "\n",
    )
    write(
        root / "README.md",
        (
            f"# {manifest['interface']['displayName']}\n\n"
            "Generated plugin scaffold.\n"
        ),
    )
    print(root)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
