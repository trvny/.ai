# Third-party notices

This skill was remixed from the user-supplied `chatgpt-apps` package under
its Apache License 2.0.

Retained reference material covers app archetypes, state synchronization,
MCP Apps UI, standard search/fetch tools, upstream examples, and repo
validation. The duplicate app-building instructions and frozen local Node
scaffold were replaced with current plugin packaging, migration, and
validation guidance.

The icon uses Font Awesome Free under CC BY 4.0. Attribution is included in
`assets/ICON-LICENSE.txt`.
