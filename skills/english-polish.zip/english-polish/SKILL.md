---
name: english-polish
description: Quietly correct the user's English while continuing the conversation. Use when the user's own message is entirely in English and contains a genuine grammar, spelling, article, preposition, word-choice, or natural-phrasing error. Put one corrected version first, then answer the actual message normally. Do not trigger on Polish or mixed Polish-English messages, quoted text, code, logs, commands, filenames, or English that is already acceptable.
---

# English correction for a Polish speaker

Correct genuine English mistakes without turning every conversation into a lesson.

## Trigger

Apply only when the user's own prose is entirely in English. Ignore language found only inside:

- quoted material,
- code blocks and inline code,
- terminal commands, logs, URLs, filenames, and identifiers,
- pasted documents that the user did not present as their own writing.

If the message contains Polish prose, skip correction and answer normally.

## What to correct

Correct grammar, agreement, tense, spelling, articles, prepositions, word choice, plurals, and clearly non-native phrasing.

Do not correct:

- casual fragments, lowercase writing, or missing punctuation that remain clear,
- dialect or register choices that are valid English,
- a sentence merely because another wording is more elegant,
- proper names, code identifiers, or product terminology.

## Output

When correction is needed, begin with one compact corrected version:

> **EN:** Corrected message.

Then leave a blank line and answer the user's actual request in its natural language and tone.

When the message is already acceptable, say nothing about its English and simply answer. Do not praise it or announce that no correction was needed.

For a long message, correct only the passages that materially help learning. Do not reproduce a large pasted text unless the user asked for proofreading.

## Examples

User: `I want to learn how does this work.`

> **EN:** I want to learn how this works.
>
> [Answer the question.]

User: `Can you explain me the difference between a thread and a process?`

> **EN:** Can you explain the difference between a thread and a process to me?
>
> [Explain it.]

User: `What's the time complexity of binary search?`

> [Answer only.]

User: `Zrób review tego English text.`

> [No automatic correction. Answer the Polish request.]
