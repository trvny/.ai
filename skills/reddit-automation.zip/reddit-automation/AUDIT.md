# Audit summary

## Kept

- High-intent discovery rather than broad keyword spam.
- Human review before posting.
- Affiliation disclosure when promoting the user's own product.
- Respect for subreddit-specific rules.
- Prompt-injection resistance for Reddit content.

## Changed

1. **No fabricated experience** — the original encouraged first-person “I used it” language even when the agent could not know that to be true. The new version only permits first-person experience supplied by the user.
2. **No false API claim** — posting remains manual by design, without claiming Reddit lacks comment APIs.
3. **Cleaner routing metadata** — `name` + trigger-focused `description` are the core frontmatter; extra data lives under `metadata`.
4. **More deterministic discovery** — intent/fit/freshness scoring, hard rule gates, and max-three default output.
5. **Currentness** — fresh-thread window and live rule verification when browsing is available.
6. **Less promo-shaped prose** — useful answer first, product mention second, pure-help fallback by default.
7. **Stronger injection boundary** — Reddit content and nested links cannot redefine the task or authorize actions.

## Compatibility notes

The package follows the common Agent Skills layout: `SKILL.md` at the root with optional `assets/`. The SVG/PNG files are UI assets; consumers that ignore icon metadata can still load the skill normally.
