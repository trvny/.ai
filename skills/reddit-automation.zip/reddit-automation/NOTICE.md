# Notice

This adaptation is based on the MIT-licensed `reddit-automation` skill by doany.ai / doany-skills.

Changes in this version include:

- Agent Skills / OpenAI-friendly frontmatter and folder layout.
- Removed non-standard top-level metadata fields.
- Replaced the instruction to simulate first-person product experience with an explicit prohibition on fabricated experience.
- Corrected the implication that Reddit lacks comment-posting APIs; this skill simply does not automate posting.
- Added deterministic opportunity scoring and clearer output modes.
- Added freshness, subreddit-rule, saturation, and current-policy checks.
- Strengthened prompt-injection handling for Reddit content and linked material.
- Added original Reddit-inspired UI assets in SVG and PNG formats.

Reddit and its marks are trademarks of Reddit, Inc. This package is not affiliated with or endorsed by Reddit, Inc.
