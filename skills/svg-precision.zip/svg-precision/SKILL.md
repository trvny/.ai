---
name: svg-precision
description: Create, repair, validate, render, and compare deterministic SVG files from explicit geometry or a structured JSON scene spec. Use for editable icons, logos, diagrams, flowcharts, charts, UI wireframes, technical drawings, SVG cleanup, viewBox or clipping bugs, inaccessible SVGs, and pixel-diff verification. Prefer this over image generation when the user needs exact coordinates, reusable vector markup, reproducible output, or validation.
---

# SVG Precision

Produce exact, editable SVG rather than a visually plausible raster approximation.

## Choose the workflow

- **Structured build:** translate the request into the JSON schema in `references/spec.md`, then use `scripts/svg_cli.py check` and `build`.
- **Repair existing SVG:** inspect the source, make the smallest markup change, then run `validate` and render a preview.
- **Regression comparison:** render both files at the same scale and use `diff`.
- **Loose artistic image:** this skill is the wrong tool when exact SVG structure is not required.

## Standard workflow

1. Fix the canvas dimensions and `viewBox` before placing elements.
2. Use absolute coordinates and reusable groups, defs, gradients, markers, and clip paths.
3. Add a meaningful title and description for non-decorative graphics.
4. Keep external dependencies out of the SVG. Embed required raster images as data URIs unless the user explicitly accepts external loading.
5. Run:

```bash
python3 scripts/svg_cli.py check spec.json
python3 scripts/svg_cli.py build spec.json output.svg
python3 scripts/svg_cli.py validate output.svg
python3 scripts/svg_cli.py render output.svg preview.png --scale 2
```

6. Inspect the preview when rendering is available. Validation alone cannot catch every visual overlap or optical-alignment problem.
7. Return the SVG and, when useful, the PNG preview. State if rendering dependencies were unavailable.

## Rules

- Set `viewBox`, width, and height explicitly.
- Prefer simple shapes and paths over fragile filters or renderer-specific effects.
- Use consistent stroke widths, line caps, joins, spacing, and optical alignment.
- Treat text as non-deterministic across machines unless the font is controlled or text is converted to paths.
- Never include scripts, event-handler attributes, `foreignObject`, or hidden remote loads.
- Keep IDs unique and verify every `url(#id)` reference.
- For icons, inspect at the final display size, not only zoomed in.
- For technical drawings and charts, encode data and dimensions in the spec rather than eyeballing them.

Read `references/recipes.md` for layout patterns and `references/spec.md` for the supported JSON schema.
