# CI diagnosis reference

## Read logs in this order

1. job conclusion and failed step,
2. first actionable compiler, test, lint, configuration, or permission error,
3. surrounding context,
4. final process exit only as confirmation.

## Common false leads

- `Process completed with exit code 1` is usually only the wrapper.
- cleanup failures may appear after the real test failure.
- artifact upload failures can mask a successful build but still block the workflow.
- a cancelled downstream job may be innocent when an upstream dependency failed.
- a matrix summary can hide one failing OS, JDK, language, or architecture leg.

## External checks

If the check URL is not a GitHub Actions run, identify the provider and use
its details page or API when available. Do not label missing GitHub logs as
an Actions outage.

## Merge gate

Before merge, verify:

- required checks are green on the current head SHA,
- there are no unresolved review threads,
- the branch did not move after the successful run,
- the chosen merge method matches repository policy.

## Minimal fixes

Prefer fixing the source defect over suppressing the check. If the check is
wrong, narrow the workflow or configuration change to the demonstrated
mismatch and preserve existing security boundaries.
