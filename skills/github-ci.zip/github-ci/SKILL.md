---
name: github-ci
description: Diagnose and repair failing GitHub pull-request checks and GitHub Actions runs. Use when a PR is red, a workflow or job failed, CI is cancelled or timed out, a user pastes an Actions log, or asks why tests, lint, builds, deployment, dependency submission, or release automation failed. Inspect current PR metadata, checks, runs, jobs, steps, and logs; isolate the first actionable root cause; propose or implement the smallest focused fix; then verify the new run. Do not use for general GitHub repository work without a CI failure.
---

# GitHub CI

Diagnose CI from the outside inward. A red badge is a symptom, not a root cause.

## Workflow

1. Resolve the repository and PR or commit. Read the current PR metadata and head SHA.
2. Inspect the combined check status and workflow runs for that exact SHA.
3. Separate:
   - GitHub Actions checks with accessible runs/jobs/logs,
   - external checks whose details live at another provider,
   - pending or cancelled checks with incomplete logs.
4. For an Actions failure, read the failed job's step summaries and logs. Prefer the job log over the entire run log when available.
5. Extract the last strong failure marker with enough surrounding context. Use `scripts/extract_failure.py` for downloaded or pasted logs.
6. Distinguish the primary failure from follow-on noise. The first compiler/test/configuration error is usually more useful than the final `Process completed with exit code 1`.
7. Read the relevant source and workflow files before changing anything.
8. Make one focused fix. Do not bundle unrelated workflow cleanup or refactors into the same repair.
9. Re-read the changed files and verify the new workflow run for the new head SHA.
10. Report the failed check, root cause, evidence, exact fix, and verification status.

## Tool routing

Prefer the GitHub connector capabilities available in the current session:

- PR metadata and head SHA,
- combined commit checks,
- workflow runs for a commit,
- jobs and step summaries for a run,
- decoded job logs,
- review threads when a requested change may also block merge.

Exact action names vary by host. Discover and use the available GitHub tools rather than requiring a local checkout or authenticated `gh` CLI.

A local `gh` or shell route is optional when already authenticated. Never ask the user to paste a GitHub token into chat.

## Diagnosis rules

- **External check:** report the provider and details URL. Do not pretend GitHub Actions logs exist.
- **Pending logs:** wait or re-check after completion. Do not diagnose from an empty archive.
- **Cancelled run:** determine whether cancellation was manual, concurrency-related, or a downstream effect.
- **Matrix jobs:** identify the exact matrix leg and do not generalize from a passing sibling.
- **Repeated failures:** compare the failing step and message across attempts before changing code again.
- **Infrastructure flake:** rerun only when evidence points to transient infrastructure, not to deterministic source failure.
- **Security or permissions failure:** do not loosen permissions broadly. Find the narrow missing permission or event limitation.

## Output

Keep the report compact:

- check/job,
- root cause,
- decisive log excerpt or step,
- files changed,
- verification run and conclusion,
- remaining blockers.

Read `references/diagnosis.md` for log patterns and merge-gate handling.
