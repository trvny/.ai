# Third-party notices

The CI log-classification and failure-window approach was adapted from the
user-supplied `gh-fix-ci` skill under the Apache License 2.0. The remix
removes the mandatory local Git repository, authenticated `gh` CLI, and
direct PR-check JSON compatibility logic, replacing them with
connector-native workflow guidance and a standalone log analyzer.
