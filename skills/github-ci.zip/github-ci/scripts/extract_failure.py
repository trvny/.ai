#!/usr/bin/env python3
"""Extract the most actionable failure window from GitHub Actions or CI logs."""

from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path
from typing import Sequence

ANSI_RE = re.compile(r"\x1b\[[0-?]*[ -/]*[@-~]")
PREFIX_RE = re.compile(
    r"^(?:\d{4}-\d{2}-\d{2}T[0-9:.]+Z\s+)?(?:[^\t]+\t[^\t]+\t)?"
)

STRONG_PATTERNS = (
    (re.compile(r"(^|\s)(error|fatal|panic|traceback|exception)(\s|:)", re.I), 100),
    (re.compile(r"(assertionerror|tests? failed|compilation failed|lint errors?)", re.I), 95),
    (re.compile(r"(permission denied|resource not accessible|403 forbidden)", re.I), 90),
    (re.compile(r"(no such file|not found|cannot find|module not found)", re.I), 85),
    (re.compile(r"(timed out|timeout|out of memory|oom|segmentation fault)", re.I), 80),
    (re.compile(r"##\[error\]", re.I), 75),
    (re.compile(r"\bfail(?:ed|ure)?\b", re.I), 60),
)
WEAK_WRAPPER_PATTERNS = (
    re.compile(r"process completed with exit code", re.I),
    re.compile(r"the command .* exited with", re.I),
    re.compile(r"error: process completed", re.I),
)
SECRET_PATTERNS = (
    re.compile(r"\bgh[pousr]_[A-Za-z0-9_]{20,}\b"),
    re.compile(r"\bsk-[A-Za-z0-9_-]{20,}\b"),
    re.compile(r"(?i)(authorization:\s*(?:bearer|token)\s+)[^\s]+"),
)


def clean_line(line: str) -> str:
    line = ANSI_RE.sub("", line.rstrip("\r\n"))
    return PREFIX_RE.sub("", line)


def redact(text: str) -> str:
    for pattern in SECRET_PATTERNS:
        text = pattern.sub(
            lambda match: (match.group(1) if match.lastindex else "") + "[REDACTED]",
            text,
        )
    return text


def score_line(line: str) -> int:
    if any(pattern.search(line) for pattern in WEAK_WRAPPER_PATTERNS):
        return 10
    score = 0
    for pattern, value in STRONG_PATTERNS:
        if pattern.search(line):
            score = max(score, value)
    if re.search(r"\bwarning\b", line, re.I):
        score = max(score, 20)
    return score


def choose_index(lines: Sequence[str]) -> tuple[int | None, int]:
    best_index: int | None = None
    best_score = 0
    for index, line in enumerate(lines):
        score = score_line(line)
        # Later errors win only when equally strong. This avoids the final
        # wrapper line replacing a concrete compiler/test failure.
        if score > best_score or (score == best_score and score >= 60):
            best_index, best_score = index, score
    return best_index, best_score


def extract(text: str, before: int, after: int, max_lines: int) -> dict:
    lines = [clean_line(line) for line in text.splitlines()]
    index, score = choose_index(lines)
    if index is None:
        window = lines[-max_lines:]
        start = max(0, len(lines) - len(window))
        end = len(lines)
    else:
        start = max(0, index - before)
        end = min(len(lines), index + after + 1)
        window = lines[start:end]
        if len(window) > max_lines:
            window = window[-max_lines:]
            start = end - len(window)

    snippet = redact("\n".join(window)).strip()
    decisive = redact(lines[index]).strip() if index is not None else ""
    return {
        "marker_index": index,
        "marker_score": score,
        "decisive_line": decisive,
        "window_start": start,
        "window_end": end,
        "snippet": snippet,
        "line_count": len(lines),
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("log", nargs="?", help="Log file; stdin if omitted")
    parser.add_argument("--before", type=int, default=30)
    parser.add_argument("--after", type=int, default=30)
    parser.add_argument("--max-lines", type=int, default=160)
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args()

    if min(args.before, args.after, args.max_lines) < 0 or args.max_lines == 0:
        parser.error("context values must be non-negative and max-lines positive")

    if args.log:
        text = Path(args.log).read_text(encoding="utf-8", errors="replace")
    else:
        text = sys.stdin.read()

    result = extract(text, args.before, args.after, args.max_lines)
    if args.json:
        print(json.dumps(result, indent=2))
    else:
        if result["decisive_line"]:
            print(f"Decisive line: {result['decisive_line']}")
        print(result["snippet"])
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
