# Audit checklist

## Should this be a skill?

- Read `surface-map.md`
- Confirm this is a reusable workflow, not a one-off prompt or style preset
- Avoid duplicating a built-in skill without a narrower role

## Structure and archive

- One root directory and one root `SKILL.md`
- No path traversal, symlinks, special files, encryption or case collisions
- Bounded file count, expanded size, per-file size and compression ratio
- Valid YAML frontmatter
- Name and root folder aligned
- Referenced files exist
- No generated caches, build artifacts or nested packages

## Triggering

- Description says what the skill does
- Description says when to use it
- Project-specific skills name the project and boundary
- Generic keywords do not capture unrelated requests

## Runtime assumptions

- No stale tool identifiers
- No mandatory subagents or slash commands unless supported
- No claim that auth, browser, shell, checkout or connector always exists
- External writes remain explicit and verifiable

## Trust and scripts

- Read scripts before execution
- Network, process, delete and filesystem behavior matches the description
- No embedded keys, private keys, bearer tokens or mutable resource IDs
- SVG icons contain no active or remote content
- Third-party licenses and notices are preserved

## Content and packaging

- `SKILL.md` is a router, not an encyclopedia
- Volatile API facts point to live primary docs
- References are focused and linked
- Package deterministically and audit the produced archive again
- Smoke prompts cover positive, negative and boundary triggers
