# Choose the smallest durable surface

Before creating or expanding a skill, decide whether a skill is the right
container.

| Need | Better surface |
|---|---|
| One-off requirement for the current task | Prompt or thread context |
| Durable repository conventions, commands, verification and review rules | `AGENTS.md` or equivalent project instructions |
| Runtime, sandbox, model, tool or connector settings | Project/global configuration |
| Default voice, brevity, warmth or humor | User settings, personality, or style instructions |
| Reusable task workflow with references or scripts | Skill |
| Installable bundle of skills, tools, commands, hooks and assets | Plugin or app |
| Live private or changing external data and actions | Connector or MCP server |
| Scheduled checks, reminders or future monitoring | Automation |
| Mechanical enforcement around commands, tool calls or edits | Hook, policy, linter or CI |

Split mixed-scope requests. A workflow can live in a skill while its
repository invariants live in `AGENTS.md`, its live data comes from a
connector, and its future checks are automations.

A style is not a workflow. Do not create an always-on style skill merely
because another product lacks personality settings.
