# Archive safety

Treat a `.skill` file as untrusted input until inspected.

Reject:

- absolute paths, drive-letter paths, UNC paths and `..` traversal,
- symbolic links and special device files,
- encrypted members,
- case-colliding or Unicode-normalization-colliding paths,
- excessive file counts, expanded size or per-file size,
- suspicious compression ratios,
- active SVG content such as scripts, event handlers, `foreignObject` or remote loads.

Do not call `extractall()` before validating every member. Extract by
streaming each validated regular file into a temporary directory.

Script warnings are not automatic proof of malice. Network, subprocess,
delete and external-write behavior should be read and matched against the
skill's advertised purpose before execution.
