---
name: skill-auditor
description: Audit, repair, migrate, harden, and package Agent Skills for ChatGPT, Codex, and compatible Agent Skills runtimes. Use when an uploaded skill will not install, does not trigger, triggers too broadly, may not belong in a skill at all, contains Claude Code or another harness's assumptions, has stale connector names, duplicate metadata, missing or unsafe icons, oversized bundled material, suspicious scripts, unsafe archives, missing licenses, or needs a clean `.skill` package. For creating a brand-new skill, use the platform's built-in skill creator first; use this skill for compatibility, security, scope, and quality review.
---

# Skill Auditor

Audit a skill as a portable workflow, not merely a ZIP that parses.

## Workflow

1. **Choose the surface.** Read `references/surface-map.md`. Confirm the material belongs in a reusable skill rather than a prompt, project instructions, settings, connector, automation, hook, plugin, or style.
2. **Inspect the archive safely.** Validate paths, file types, counts, sizes, compression ratios, duplicates, symlinks and encryption before extraction. See `references/archive-safety.md`.
3. **Inventory** the package: root folder, `SKILL.md`, `agents/openai.yaml`, references, scripts, assets, licenses, and total size.
4. **Validate structure and metadata** with `scripts/audit_skill.py`.
5. **Review triggers** for under-triggering, over-triggering, collisions with installed skills, and accidental duplication of built-ins.
6. **Audit environment assumptions**: tool names, connector availability, local persistence, authentication, subagents, slash commands, browser viewers, and platform-specific CLI calls.
7. **Audit trust boundaries**: read every executable script, flag hidden network/write/delete behavior, scan for secrets, validate SVG icons, and preserve third-party notices.
8. **Trim resources**: remove generated output, obsolete PDFs, dormant agents, duplicate docs, and static API copies likely to age. Keep stable methods, templates, scripts, and focused references.
9. **Repair progressively**: scope and metadata first, then triggers, workflow/tools, references, scripts, and packaging.
10. **Test** with a trigger matrix and one realistic task.
11. **Package** with `scripts/package_skill.py`, then audit the produced archive again.

## Compatibility principles

- Keep one root directory with one top-level `SKILL.md`.
- Use a lowercase kebab-case name and a concrete description containing capability and trigger conditions.
- Keep UI metadata short and verify icon paths.
- Do not hardcode tools from another runtime. Route by capability and inspect what is available.
- Do not assert that a connector, account, shell, browser or authenticated checkout always exists.
- Do not embed secrets, account IDs, database IDs, namespace IDs, or mutable deployment configuration when they can be discovered.
- Prefer live primary documentation for volatile APIs and limits.
- A skill should not silently take external write actions merely because it was triggered.

## Output

Return:

- verdict: keep, trim, rebuild, merge, move to another surface, or remove;
- defects and their impact;
- files changed or removed;
- archive/security findings;
- validation and test results;
- the final `.skill` package.

Do not claim installation succeeded unless the target product actually accepted the package.
