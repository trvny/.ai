#!/usr/bin/env python3
"""Audit an Agent Skill directory or archive for compatibility, safety, and quality."""

from __future__ import annotations

import argparse
import json
import os
import re
import shutil
import stat
import tempfile
import unicodedata
import zipfile
from pathlib import Path, PurePosixPath
from typing import Any
from xml.etree import ElementTree

try:
    import yaml
except ImportError as exc:
    raise SystemExit("PyYAML is required: pip install pyyaml") from exc


NAME_RE = re.compile(r"^[a-z0-9]+(?:-[a-z0-9]+)*$")
WINDOWS_DRIVE_RE = re.compile(r"^[A-Za-z]:")
ALLOWED_FRONTMATTER = {
    "name",
    "description",
    "license",
    "allowed-tools",
    "metadata",
    "compatibility",
}
TEXT_SUFFIXES = {
    ".md", ".txt", ".yaml", ".yml", ".json", ".py", ".js", ".mjs",
    ".cjs", ".ts", ".tsx", ".sh", ".ps1", ".toml",
}
JUNK_NAMES = {".DS_Store", "Thumbs.db"}
JUNK_DIRS = {"__MACOSX", "__pycache__", ".pytest_cache", ".mypy_cache"}
SUSPICIOUS_RUNTIME = {
    "claude -p": "Claude CLI dependency",
    "~/.claude": "Claude-specific home directory",
    "/compact": "runtime-specific slash command",
    "/context": "runtime-specific slash command",
    "github:get_file_contents": "stale connector action name",
    "github:push_files": "stale connector action name",
    "cloudflare:execute": "hardcoded connector action name",
    "spawn subagents": "mandatory subagent assumption",
    "$codex_home": "Codex-home installation assumption",
}
NETWORK_MARKERS = (
    "requests.", "httpx.", "urllib.request", "urlopen(", "fetch(",
    "socket.", "curl ", "wget ", "github_request(",
)
DESTRUCTIVE_MARKERS = (
    "shutil.rmtree(", "os.remove(", ".unlink(", "rm -rf", "delete_file",
    "subprocess.run(", "os.system(", "shell=true",
)
SECRET_PATTERNS = {
    "OpenAI-style key": re.compile(r"\bsk-(?:proj-)?[A-Za-z0-9_-]{16,}\b"),
    "GitHub token": re.compile(r"\bgh[pousr]_[A-Za-z0-9_]{20,}\b"),
    "private key": re.compile(r"-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----"),
    "bearer token": re.compile(r"(?i)\bauthorization\s*[:=]\s*[\"']?bearer\s+[A-Za-z0-9._-]{16,}"),
}


class AuditError(ValueError):
    pass


def canonical_member_name(name: str) -> str:
    normalized = unicodedata.normalize("NFC", name.replace("\\", "/"))
    return normalized.casefold().rstrip("/")


def is_symlink(info: zipfile.ZipInfo) -> bool:
    mode = (info.external_attr >> 16) & 0xFFFF
    return stat.S_IFMT(mode) == stat.S_IFLNK


def validate_archive(
    archive: zipfile.ZipFile,
    *,
    max_members: int,
    max_total_size: int,
    max_file_size: int,
    max_ratio: float,
) -> list[str]:
    infos = archive.infolist()
    if len(infos) > max_members:
        raise AuditError(f"archive has {len(infos)} members; limit is {max_members}")

    total = 0
    seen: dict[str, str] = {}
    for info in infos:
        name = info.filename
        if "\x00" in name:
            raise AuditError("archive contains a NUL byte in a member name")
        if name.startswith(("/", "\\")) or WINDOWS_DRIVE_RE.match(name):
            raise AuditError(f"absolute archive path: {name!r}")
        pure = PurePosixPath(name.replace("\\", "/"))
        if ".." in pure.parts:
            raise AuditError(f"path traversal in archive member: {name!r}")
        if is_symlink(info):
            raise AuditError(f"archive contains a symbolic link: {name!r}")
        if info.flag_bits & 0x1:
            raise AuditError(f"archive contains an encrypted member: {name!r}")
        if not info.is_dir():
            mode = (info.external_attr >> 16) & 0xFFFF
            file_type = stat.S_IFMT(mode)
            if file_type not in {0, stat.S_IFREG}:
                raise AuditError(f"archive contains a special file: {name!r}")
            if info.file_size > max_file_size:
                raise AuditError(
                    f"{name!r} is {info.file_size} bytes; per-file limit is {max_file_size}"
                )
            total += info.file_size
            if total > max_total_size:
                raise AuditError(
                    f"archive expands beyond {max_total_size} bytes"
                )
            if info.compress_size == 0:
                ratio = float("inf") if info.file_size else 1.0
            else:
                ratio = info.file_size / info.compress_size
            if info.file_size >= 1_000_000 and ratio > max_ratio:
                raise AuditError(
                    f"suspicious compression ratio {ratio:.1f}x for {name!r}"
                )

        key = canonical_member_name(name)
        if key in seen and seen[key] != name:
            raise AuditError(
                f"duplicate/case-colliding archive members: {seen[key]!r} and {name!r}"
            )
        seen[key] = name
    return [info.filename for info in infos]


def safe_extract(archive: zipfile.ZipFile, destination: Path) -> None:
    root = destination.resolve()
    for info in archive.infolist():
        pure = PurePosixPath(info.filename.replace("\\", "/"))
        target = destination.joinpath(*pure.parts)
        resolved_parent = target.parent.resolve()
        if resolved_parent != root and root not in resolved_parent.parents:
            raise AuditError(f"member escapes extraction root: {info.filename!r}")
        if info.is_dir():
            target.mkdir(parents=True, exist_ok=True)
            continue
        target.parent.mkdir(parents=True, exist_ok=True)
        with archive.open(info, "r") as source, target.open("wb") as output:
            shutil.copyfileobj(source, output, length=1024 * 1024)


def load_root(
    path: Path,
    temporary: Path,
    *,
    max_members: int,
    max_total_size: int,
    max_file_size: int,
    max_ratio: float,
) -> Path:
    if path.is_dir():
        return path.resolve()
    if path.suffix.lower() not in {".zip", ".skill"}:
        raise AuditError("input must be a skill directory, .zip, or .skill archive")
    with zipfile.ZipFile(path) as archive:
        validate_archive(
            archive,
            max_members=max_members,
            max_total_size=max_total_size,
            max_file_size=max_file_size,
            max_ratio=max_ratio,
        )
        safe_extract(archive, temporary)
    roots = [
        item for item in temporary.iterdir()
        if item.name not in JUNK_DIRS and item.name not in JUNK_NAMES
    ]
    if len(roots) != 1 or not roots[0].is_dir():
        raise AuditError("archive must contain exactly one root directory")
    return roots[0]


def parse_frontmatter(text: str) -> tuple[dict[str, Any], str]:
    if not text.startswith("---\n"):
        raise AuditError("SKILL.md must begin with YAML frontmatter")
    end = text.find("\n---\n", 4)
    if end < 0:
        raise AuditError("unterminated YAML frontmatter")
    data = yaml.safe_load(text[4:end]) or {}
    if not isinstance(data, dict):
        raise AuditError("frontmatter must be a mapping")
    return data, text[end + 5 :]


def iter_text_files(root: Path):
    for path in root.rglob("*"):
        if path.is_file() and path.suffix.lower() in TEXT_SUFFIXES:
            yield path


def audit_svg(path: Path) -> tuple[list[str], list[str]]:
    errors: list[str] = []
    warnings: list[str] = []
    text = path.read_text(encoding="utf-8", errors="replace")
    lowered = text.lower()
    if "<script" in lowered:
        errors.append(f"{path.name}: SVG contains script")
    if "<foreignobject" in lowered:
        errors.append(f"{path.name}: SVG contains foreignObject")
    if re.search(r"\son[a-z]+\s*=", lowered):
        errors.append(f"{path.name}: SVG contains an event-handler attribute")
    if re.search(r"(?:href|xlink:href)\s*=\s*[\"'](?:https?:|//|data:text/html)", lowered):
        errors.append(f"{path.name}: SVG loads an external or active resource")
    if re.search(r"url\(\s*[\"']?(?:https?:|//)", lowered):
        errors.append(f"{path.name}: SVG CSS loads an external resource")
    try:
        ElementTree.fromstring(text)
    except ElementTree.ParseError as exc:
        errors.append(f"{path.name}: invalid SVG XML: {exc}")
    if len(text) > 500_000:
        warnings.append(f"{path.name}: unusually large SVG ({len(text)} characters)")
    return errors, warnings


def audit(root: Path) -> dict[str, Any]:
    errors: list[str] = []
    warnings: list[str] = []
    info: list[str] = []

    for path in root.rglob("*"):
        if path.is_symlink():
            errors.append(f"symbolic link is not allowed: {path.relative_to(root)}")
        if path.name in JUNK_NAMES or any(part in JUNK_DIRS for part in path.parts):
            warnings.append(f"generated/junk path: {path.relative_to(root)}")

    skill_md = root / "SKILL.md"
    if not skill_md.exists():
        return {"errors": ["missing root SKILL.md"], "warnings": warnings, "info": info}
    nested = [path for path in root.rglob("SKILL.md") if path != skill_md]
    if nested:
        errors.append(
            "nested SKILL.md files: "
            + ", ".join(str(path.relative_to(root)) for path in nested)
        )

    try:
        frontmatter, body = parse_frontmatter(skill_md.read_text(encoding="utf-8"))
    except Exception as exc:
        return {"errors": [str(exc)], "warnings": warnings, "info": info}

    unknown_keys = sorted(set(frontmatter) - ALLOWED_FRONTMATTER)
    if unknown_keys:
        warnings.append(
            "non-portable frontmatter keys: " + ", ".join(unknown_keys)
        )

    name = frontmatter.get("name")
    description = frontmatter.get("description")
    if not isinstance(name, str) or not NAME_RE.fullmatch(name):
        errors.append("frontmatter name must be lowercase kebab-case")
    elif root.name != name:
        warnings.append(f"root folder {root.name!r} differs from skill name {name!r}")
    if not isinstance(description, str) or not description.strip():
        errors.append("frontmatter description is required")
    elif len(description) > 1024:
        errors.append(
            f"description is {len(description)} characters; maximum expected is 1024"
        )
    elif len(description) < 40:
        warnings.append("description may be too short to trigger reliably")
    if len(body.splitlines()) > 500:
        warnings.append("SKILL.md body exceeds 500 lines; move detail to references")

    agent = root / "agents/openai.yaml"
    if agent.exists():
        try:
            data = yaml.safe_load(agent.read_text(encoding="utf-8")) or {}
            interface = data.get("interface", data)
            if not isinstance(interface, dict):
                errors.append("agents/openai.yaml interface must be a mapping")
            else:
                short = interface.get("short_description")
                if isinstance(short, str) and len(short) > 100:
                    warnings.append("UI short_description is long; keep it label-sized")
                for key in ("icon_small", "icon_large"):
                    value = interface.get(key)
                    if value:
                        target = root / str(value).removeprefix("./")
                        try:
                            target.resolve().relative_to(root.resolve())
                        except ValueError:
                            errors.append(f"{key} escapes the skill root: {value}")
                            continue
                        if not target.exists():
                            errors.append(f"{key} points to missing file: {value}")
                        elif target.suffix.lower() == ".svg":
                            svg_errors, svg_warnings = audit_svg(target)
                            errors.extend(svg_errors)
                            warnings.extend(svg_warnings)
        except Exception as exc:
            errors.append(f"invalid agents/openai.yaml: {exc}")
    else:
        warnings.append("missing agents/openai.yaml UI metadata")

    if not any((root / name).exists() for name in ("LICENSE", "LICENSE.txt", "LICENSE.md")):
        warnings.append("no top-level license file; add one or document third-party licenses")

    all_text_parts: list[str] = []
    for path in iter_text_files(root):
        if path.name == "audit_skill.py":
            continue
        text = path.read_text(encoding="utf-8", errors="ignore")
        all_text_parts.append(text)
        lowered = text.lower()

        if path.suffix.lower() in {".py", ".js", ".mjs", ".cjs", ".ts", ".tsx", ".sh", ".ps1"}:
            network_hits = [marker for marker in NETWORK_MARKERS if marker in lowered]
            destructive_hits = [marker for marker in DESTRUCTIVE_MARKERS if marker in lowered]
            if network_hits:
                warnings.append(
                    f"{path.relative_to(root)} has network-capable code: {', '.join(network_hits[:4])}"
                )
            if destructive_hits:
                warnings.append(
                    f"{path.relative_to(root)} has write/delete/process behavior: {', '.join(destructive_hits[:4])}"
                )

    all_text = "\n".join(all_text_parts)
    lowered_all = all_text.lower()
    for needle, label in SUSPICIOUS_RUNTIME.items():
        if needle in lowered_all:
            warnings.append(f"{label}: found {needle!r}")

    for label, pattern in SECRET_PATTERNS.items():
        if pattern.search(all_text):
            errors.append(f"possible embedded {label}")

    long_hex = re.findall(r"\b[a-fA-F0-9]{32,64}\b", all_text)
    if long_hex:
        warnings.append(
            f"found {len(set(long_hex))} long hex identifier(s); verify they are not secrets or mutable resource IDs"
        )

    markdown_references = set(
        re.findall(
            r"(?<![A-Za-z0-9_.-])((?:references|scripts|assets)/[A-Za-z0-9_./-]+)",
            all_text,
        )
    )
    for reference in sorted(markdown_references):
        clean = reference.rstrip("`'\".,:;)")
        target = root / clean
        try:
            target.resolve().relative_to(root.resolve())
        except ValueError:
            errors.append(f"reference escapes skill root: {clean}")
            continue
        if not target.exists():
            warnings.append(f"text references missing path: {clean}")

    file_count = sum(1 for path in root.rglob("*") if path.is_file())
    total_size = sum(path.stat().st_size for path in root.rglob("*") if path.is_file())
    info.extend([f"files={file_count}", f"bytes={total_size}"])
    return {
        "errors": sorted(set(errors)),
        "warnings": sorted(set(warnings)),
        "info": info,
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("path", type=Path)
    parser.add_argument("--max-members", type=int, default=2500)
    parser.add_argument("--max-total-size", type=int, default=150 * 1024 * 1024)
    parser.add_argument("--max-file-size", type=int, default=25 * 1024 * 1024)
    parser.add_argument("--max-compression-ratio", type=float, default=200.0)
    args = parser.parse_args()

    with tempfile.TemporaryDirectory() as temporary:
        try:
            root = load_root(
                args.path,
                Path(temporary),
                max_members=args.max_members,
                max_total_size=args.max_total_size,
                max_file_size=args.max_file_size,
                max_ratio=args.max_compression_ratio,
            )
            report = audit(root)
        except Exception as exc:
            report = {"errors": [str(exc)], "warnings": [], "info": []}
    print(json.dumps(report, indent=2, ensure_ascii=False))
    return 1 if report["errors"] else 0


if __name__ == "__main__":
    raise SystemExit(main())
