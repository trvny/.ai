#!/usr/bin/env python3
"""Validate and deterministically package an Agent Skill."""

from __future__ import annotations

import argparse
import os
import stat
import subprocess
import sys
import zipfile
from pathlib import Path

JUNK_NAMES = {".DS_Store", "Thumbs.db"}
JUNK_DIRS = {"__MACOSX", "__pycache__", ".pytest_cache", ".mypy_cache"}


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("skill_dir", type=Path)
    parser.add_argument("output", type=Path, nargs="?")
    args = parser.parse_args()

    skill_dir = args.skill_dir.resolve()
    if not skill_dir.is_dir():
        raise SystemExit("skill_dir is not a directory")
    if any(path.is_symlink() for path in skill_dir.rglob("*")):
        raise SystemExit("skill contains symbolic links; package not created")

    audit = Path(__file__).with_name("audit_skill.py")
    result = subprocess.run([sys.executable, str(audit), str(skill_dir)], check=False)
    if result.returncode:
        raise SystemExit("audit failed; package not created")

    output = (args.output or skill_dir.with_suffix(".skill")).resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    if output == skill_dir or skill_dir in output.parents:
        raise SystemExit("output must be outside the skill directory")

    with zipfile.ZipFile(
        output, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9
    ) as archive:
        for path in sorted(skill_dir.rglob("*")):
            if not path.is_file():
                continue
            relative = path.relative_to(skill_dir)
            if (
                path.name in JUNK_NAMES
                or any(part in JUNK_DIRS for part in relative.parts)
                or path.suffix == ".pyc"
            ):
                continue
            arc = Path(skill_dir.name) / relative
            info = zipfile.ZipInfo(str(arc).replace(os.sep, "/"))
            info.date_time = (2020, 1, 1, 0, 0, 0)
            info.external_attr = (
                (0o755 if path.suffix in {".py", ".sh"} else 0o644) << 16
            )
            archive.writestr(
                info,
                path.read_bytes(),
                compress_type=zipfile.ZIP_DEFLATED,
                compresslevel=9,
            )
    print(output)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
