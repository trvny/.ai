# Third-party notices

Archive-path validation ideas were adapted from the user-supplied
`skill-installer` package under Apache License 2.0.

The durable-surface selection map was adapted from the user-supplied
`openai-docs` package under Apache License 2.0, generalized beyond Codex
and stripped of product-version-specific documentation routing.

Full license texts are included under `licenses/`.
